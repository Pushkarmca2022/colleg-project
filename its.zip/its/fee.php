<?php
require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Fees Details</h1>
				</div>
			</div>
		</div>
	</header>
	<!-- container -->
	<div class="container">
		<div class="row">
			<!-- Article content -->
			<section class="col-sm-12 maincontent">
				<h3>Here is our Fee Details</h3>
				<p>
					Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
				</p>

			</section>
		</div>
	</div>
	<!-- /container -->
		
	<div class="container">
		<div class="row">
			<div class='col-sm-12'>
				<h4>M.C.A  Master of Computer Science</h4>
			</div>
			<div class='col-sm-6 col-xs-6'>
				<p>Duration</p>
				<p>Registration Fee (Only Once):</p>
				<p>Fee (Per Semester):</p>
			</div>
			<div class='col-sm-6 col-xs-6'>
				<p>Semester System (4 Semester)</p>
				<p>Rs. 20,000/-</p>
				<p>Rs. 40,000/-</p>
			</div>
		
		</div>
		<hr>
		<div class="row">
			<div class='col-sm-12'>
				<h4>MS/M. Phill, COMPUTER SCIENCE, PHYSICS, MATHEMATICS</h4>
			</div>
			<div class='col-sm-6 col-xs-6'>
				<p>Duration</p>
				<p>Registration Fee (Only Once):</p>
				<p>Fee (Per Semester)<:/p>
			</div>
			<div class='col-sm-6 col-xs-6'>
				<p>Semester System (4 Semester)</p>
				<p>Rs. 20,000/-</p>
				<p>Rs. 40,000/-</p>
			</div>
		
		</div>
		
	</div>
	
<?php
	require('footer.php');
?>