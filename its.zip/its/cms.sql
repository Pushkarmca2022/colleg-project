-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2015 at 07:49 AM
-- Server version: 5.6.15-log
-- PHP Version: 5.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE IF NOT EXISTS `announcement` (
  `announcement_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Subject` varchar(250) NOT NULL,
  `Message` varchar(250) NOT NULL,
  PRIMARY KEY (`announcement_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`announcement_Id`, `Subject`, `Message`) VALUES
(1, 'Eid holiday', 'this is testing');

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE IF NOT EXISTS `assignment` (
  `Student_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Teacher_ID` int(10) NOT NULL,
  `Subject` varchar(20) NOT NULL,
  `Submission_date` date NOT NULL,
  `Assignments` text NOT NULL,
  PRIMARY KEY (`Student_ID`,`Teacher_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `Contact_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Contact_Name` varchar(250) NOT NULL,
  `Contact_Email` varchar(250) NOT NULL,
  `Contact_Phone` int(20) NOT NULL,
  `Contact_Subject` varchar(250) NOT NULL,
  `Contact_Message` varchar(250) NOT NULL,
  PRIMARY KEY (`Contact_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Contact_Id`, `Contact_Name`, `Contact_Email`, `Contact_Phone`, `Contact_Subject`, `Contact_Message`) VALUES
(1, 'adnan', 'adnan@adnan.com', 10, 'hi', 'ssss');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=243 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES
(1, 'US', 'United States'),
(2, 'CA', 'Canada'),
(3, 'AF', 'Afghanistan'),
(4, 'AL', 'Albania'),
(5, 'DZ', 'Algeria'),
(6, 'DS', 'American Samoa'),
(7, 'AD', 'Andorra'),
(8, 'AO', 'Angola'),
(9, 'AI', 'Anguilla'),
(10, 'AQ', 'Antarctica'),
(11, 'AG', 'Antigua and/or Barbuda'),
(12, 'AR', 'Argentina'),
(13, 'AM', 'Armenia'),
(14, 'AW', 'Aruba'),
(15, 'AU', 'Australia'),
(16, 'AT', 'Austria'),
(17, 'AZ', 'Azerbaijan'),
(18, 'BS', 'Bahamas'),
(19, 'BH', 'Bahrain'),
(20, 'BD', 'Bangladesh'),
(21, 'BB', 'Barbados'),
(22, 'BY', 'Belarus'),
(23, 'BE', 'Belgium'),
(24, 'BZ', 'Belize'),
(25, 'BJ', 'Benin'),
(26, 'BM', 'Bermuda'),
(27, 'BT', 'Bhutan'),
(28, 'BO', 'Bolivia'),
(29, 'BA', 'Bosnia and Herzegovina'),
(30, 'BW', 'Botswana'),
(31, 'BV', 'Bouvet Island'),
(32, 'BR', 'Brazil'),
(33, 'IO', 'British lndian Ocean Territory'),
(34, 'BN', 'Brunei Darussalam'),
(35, 'BG', 'Bulgaria'),
(36, 'BF', 'Burkina Faso'),
(37, 'BI', 'Burundi'),
(38, 'KH', 'Cambodia'),
(39, 'CM', 'Cameroon'),
(40, 'CV', 'Cape Verde'),
(41, 'KY', 'Cayman Islands'),
(42, 'CF', 'Central African Republic'),
(43, 'TD', 'Chad'),
(44, 'CL', 'Chile'),
(45, 'CN', 'China'),
(46, 'CX', 'Christmas Island'),
(47, 'CC', 'Cocos (Keeling) Islands'),
(48, 'CO', 'Colombia'),
(49, 'KM', 'Comoros'),
(50, 'CG', 'Congo'),
(51, 'CK', 'Cook Islands'),
(52, 'CR', 'Costa Rica'),
(53, 'HR', 'Croatia (Hrvatska)'),
(54, 'CU', 'Cuba'),
(55, 'CY', 'Cyprus'),
(56, 'CZ', 'Czech Republic'),
(57, 'DK', 'Denmark'),
(58, 'DJ', 'Djibouti'),
(59, 'DM', 'Dominica'),
(60, 'DO', 'Dominican Republic'),
(61, 'TP', 'East Timor'),
(62, 'EC', 'Ecuador'),
(63, 'EG', 'Egypt'),
(64, 'SV', 'El Salvador'),
(65, 'GQ', 'Equatorial Guinea'),
(66, 'ER', 'Eritrea'),
(67, 'EE', 'Estonia'),
(68, 'ET', 'Ethiopia'),
(69, 'FK', 'Falkland Islands (Malvinas)'),
(70, 'FO', 'Faroe Islands'),
(71, 'FJ', 'Fiji'),
(72, 'FI', 'Finland'),
(73, 'FR', 'France'),
(74, 'FX', 'France, Metropolitan'),
(75, 'GF', 'French Guiana'),
(76, 'PF', 'French Polynesia'),
(77, 'TF', 'French Southern Territories'),
(78, 'GA', 'Gabon'),
(79, 'GM', 'Gambia'),
(80, 'GE', 'Georgia'),
(81, 'DE', 'Germany'),
(82, 'GH', 'Ghana'),
(83, 'GI', 'Gibraltar'),
(84, 'GR', 'Greece'),
(85, 'GL', 'Greenland'),
(86, 'GD', 'Grenada'),
(87, 'GP', 'Guadeloupe'),
(88, 'GU', 'Guam'),
(89, 'GT', 'Guatemala'),
(90, 'GN', 'Guinea'),
(91, 'GW', 'Guinea-Bissau'),
(92, 'GY', 'Guyana'),
(93, 'HT', 'Haiti'),
(94, 'HM', 'Heard and Mc Donald Islands'),
(95, 'HN', 'Honduras'),
(96, 'HK', 'Hong Kong'),
(97, 'HU', 'Hungary'),
(98, 'IS', 'Iceland'),
(99, 'IN', 'India'),
(100, 'ID', 'Indonesia'),
(101, 'IR', 'Iran (Islamic Republic of)'),
(102, 'IQ', 'Iraq'),
(103, 'IE', 'Ireland'),
(104, 'IL', 'Israel'),
(105, 'IT', 'Italy'),
(106, 'CI', 'Ivory Coast'),
(107, 'JM', 'Jamaica'),
(108, 'JP', 'Japan'),
(109, 'JO', 'Jordan'),
(110, 'KZ', 'Kazakhstan'),
(111, 'KE', 'Kenya'),
(112, 'KI', 'Kiribati'),
(113, 'KP', 'Korea, Democratic People''s Republic of'),
(114, 'KR', 'Korea, Republic of'),
(115, 'XK', 'Kosovo'),
(116, 'KW', 'Kuwait'),
(117, 'KG', 'Kyrgyzstan'),
(118, 'LA', 'Lao People''s Democratic Republic'),
(119, 'LV', 'Latvia'),
(120, 'LB', 'Lebanon'),
(121, 'LS', 'Lesotho'),
(122, 'LR', 'Liberia'),
(123, 'LY', 'Libyan Arab Jamahiriya'),
(124, 'LI', 'Liechtenstein'),
(125, 'LT', 'Lithuania'),
(126, 'LU', 'Luxembourg'),
(127, 'MO', 'Macau'),
(128, 'MK', 'Macedonia'),
(129, 'MG', 'Madagascar'),
(130, 'MW', 'Malawi'),
(131, 'MY', 'Malaysia'),
(132, 'MV', 'Maldives'),
(133, 'ML', 'Mali'),
(134, 'MT', 'Malta'),
(135, 'MH', 'Marshall Islands'),
(136, 'MQ', 'Martinique'),
(137, 'MR', 'Mauritania'),
(138, 'MU', 'Mauritius'),
(139, 'TY', 'Mayotte'),
(140, 'MX', 'Mexico'),
(141, 'FM', 'Micronesia, Federated States of'),
(142, 'MD', 'Moldova, Republic of'),
(143, 'MC', 'Monaco'),
(144, 'MN', 'Mongolia'),
(145, 'ME', 'Montenegro'),
(146, 'MS', 'Montserrat'),
(147, 'MA', 'Morocco'),
(148, 'MZ', 'Mozambique'),
(149, 'MM', 'Myanmar'),
(150, 'NA', 'Namibia'),
(151, 'NR', 'Nauru'),
(152, 'NP', 'Nepal'),
(153, 'NL', 'Netherlands'),
(154, 'AN', 'Netherlands Antilles'),
(155, 'NC', 'New Caledonia'),
(156, 'NZ', 'New Zealand'),
(157, 'NI', 'Nicaragua'),
(158, 'NE', 'Niger'),
(159, 'NG', 'Nigeria'),
(160, 'NU', 'Niue'),
(161, 'NF', 'Norfork Island'),
(162, 'MP', 'Northern Mariana Islands'),
(163, 'NO', 'Norway'),
(164, 'OM', 'Oman'),
(165, 'PK', 'Pakistan'),
(166, 'PW', 'Palau'),
(167, 'PA', 'Panama'),
(168, 'PG', 'Papua New Guinea'),
(169, 'PY', 'Paraguay'),
(170, 'PE', 'Peru'),
(171, 'PH', 'Philippines'),
(172, 'PN', 'Pitcairn'),
(173, 'PL', 'Poland'),
(174, 'PT', 'Portugal'),
(175, 'PR', 'Puerto Rico'),
(176, 'QA', 'Qatar'),
(177, 'RE', 'Reunion'),
(178, 'RO', 'Romania'),
(179, 'RU', 'Russian Federation'),
(180, 'RW', 'Rwanda'),
(181, 'KN', 'Saint Kitts and Nevis'),
(182, 'LC', 'Saint Lucia'),
(183, 'VC', 'Saint Vincent and the Grenadines'),
(184, 'WS', 'Samoa'),
(185, 'SM', 'San Marino'),
(186, 'ST', 'Sao Tome and Principe'),
(187, 'SA', 'Saudi Arabia'),
(188, 'SN', 'Senegal'),
(189, 'RS', 'Serbia'),
(190, 'SC', 'Seychelles'),
(191, 'SL', 'Sierra Leone'),
(192, 'SG', 'Singapore'),
(193, 'SK', 'Slovakia'),
(194, 'SI', 'Slovenia'),
(195, 'SB', 'Solomon Islands'),
(196, 'SO', 'Somalia'),
(197, 'ZA', 'South Africa'),
(198, 'GS', 'South Georgia South Sandwich Islands'),
(199, 'ES', 'Spain'),
(200, 'LK', 'Sri Lanka'),
(201, 'SH', 'St. Helena'),
(202, 'PM', 'St. Pierre and Miquelon'),
(203, 'SD', 'Sudan'),
(204, 'SR', 'Suriname'),
(205, 'SJ', 'Svalbarn and Jan Mayen Islands'),
(206, 'SZ', 'Swaziland'),
(207, 'SE', 'Sweden'),
(208, 'CH', 'Switzerland'),
(209, 'SY', 'Syrian Arab Republic'),
(210, 'TW', 'Taiwan'),
(211, 'TJ', 'Tajikistan'),
(212, 'TZ', 'Tanzania, United Republic of'),
(213, 'TH', 'Thailand'),
(214, 'TG', 'Togo'),
(215, 'TK', 'Tokelau'),
(216, 'TO', 'Tonga'),
(217, 'TT', 'Trinidad and Tobago'),
(218, 'TN', 'Tunisia'),
(219, 'TR', 'Turkey'),
(220, 'TM', 'Turkmenistan'),
(221, 'TC', 'Turks and Caicos Islands'),
(222, 'TV', 'Tuvalu'),
(223, 'UG', 'Uganda'),
(224, 'UA', 'Ukraine'),
(225, 'AE', 'United Arab Emirates'),
(226, 'GB', 'United Kingdom'),
(227, 'UM', 'United States minor outlying islands'),
(228, 'UY', 'Uruguay'),
(229, 'UZ', 'Uzbekistan'),
(230, 'VU', 'Vanuatu'),
(231, 'VA', 'Vatican City State'),
(232, 'VE', 'Venezuela'),
(233, 'VN', 'Vietnam'),
(234, 'VG', 'Virgin Islands (British)'),
(235, 'VI', 'Virgin Islands (U.S.)'),
(236, 'WF', 'Wallis and Futuna Islands'),
(237, 'EH', 'Western Sahara'),
(238, 'YE', 'Yemen'),
(239, 'YU', 'Yugoslavia'),
(240, 'ZR', 'Zaire'),
(241, 'ZM', 'Zambia'),
(242, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `Course_ID` int(10) NOT NULL,
  `Course_Name` varchar(10) NOT NULL,
  `Course_code` int(10) NOT NULL,
  `Cradit_hours` int(10) NOT NULL,
  PRIMARY KEY (`Course_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `Event_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Event_Date` varchar(50) NOT NULL,
  `Event_image` varchar(250) NOT NULL,
  `Event_Description` varchar(250) NOT NULL,
  PRIMARY KEY (`Event_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`Event_Id`, `Event_Date`, `Event_image`, `Event_Description`) VALUES
(1, '0000-00-00', '11264897_1634407490108288_5500406570544578300_n.jpg', 'five'),
(2, '0000-00-00', '11209424_10153206932412585_1564740879697698840_n.jpg', 'four'),
(3, '0000-00-00', 'friends.jpg', 'three'),
(4, '04 August 2015', '10014593_1546909082251915_5775660869791959545_n.jpg', 'two'),
(5, '28 August 2015', '11221826_1628148114138774_8312654230183498966_n.jpg', 'one');

-- --------------------------------------------------------

--
-- Table structure for table `facility`
--

CREATE TABLE IF NOT EXISTS `facility` (
  `Facility_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Facility_image` varchar(250) NOT NULL,
  `Facility_Name` varchar(250) NOT NULL,
  PRIMARY KEY (`Facility_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `facility`
--

INSERT INTO `facility` (`Facility_Id`, `Facility_image`, `Facility_Name`) VALUES
(4, 'sr_shahid.jpg', 'Professor Dr. Shahid Naveed'),
(3, 'QaiserMushtaq.jpg', 'Professor Dr. Qaiser Mushtaq'),
(5, 'Dost_Khan.jpg', 'Dr. Dost Muhammad Khan Chairman'),
(6, 'Altaf_Hussain.jpg', 'Dr. Altaf Hussain Langrial Director'),
(7, 'friends.jpg', 'sir');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `Login_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `role` enum('teacher','admin','student') NOT NULL,
  PRIMARY KEY (`Login_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Login_ID`, `Email`, `Password`, `role`) VALUES
(2, 'admin', 'admin', 'admin'),
(3, 'teacher', 'teacher', 'teacher'),
(4, 'student', 'student', 'student'),
(31, 'mzeeshanbwp@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'student'),
(32, 'abss@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'student'),
(33, 'adnanghouri@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'student'),
(34, 'ali_ahmad@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'teacher');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE IF NOT EXISTS `program` (
  `Program_Id` int(10) NOT NULL AUTO_INCREMENT,
  `Programe_Name` char(10) NOT NULL,
  `Affiliated_Id` enum('IUB','UOS') NOT NULL,
  `session` int(10) NOT NULL,
  `term` varchar(10) NOT NULL,
  PRIMARY KEY (`Program_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`Program_Id`, `Programe_Name`, `Affiliated_Id`, `session`, `term`) VALUES
(3, 'BSCS1', 'UOS', 2018, '5th'),
(4, 'BSIT', 'UOS', 2012, '5th'),
(5, 'MSc(IT)', 'UOS', 2012, '5th'),
(6, 'MSc(IT)', 'UOS', 2013, '3rd');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE IF NOT EXISTS `result` (
  `Result_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Program_Id` int(250) NOT NULL,
  `Roll_No` int(11) NOT NULL,
  `Marks` double NOT NULL,
  `Gpa` double NOT NULL,
  `Cgpa` double NOT NULL,
  PRIMARY KEY (`Result_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`Result_Id`, `Program_Id`, `Roll_No`, `Marks`, `Gpa`, `Cgpa`) VALUES
(1, 4, 27, 22, 3.4, 3.9),
(2, 4, 27, 22, 3.4, 3.9);

-- --------------------------------------------------------

--
-- Table structure for table `student_record`
--

CREATE TABLE IF NOT EXISTS `student_record` (
  `Student_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Roll_no` int(50) NOT NULL,
  `Name` char(50) NOT NULL,
  `F_Name` char(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `CNIC` varchar(50) NOT NULL,
  `City` char(50) NOT NULL,
  `Country` char(50) NOT NULL,
  `Religion` char(20) NOT NULL,
  `Mobile` varchar(20) NOT NULL,
  `Program` char(20) NOT NULL,
  `Session` int(10) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  PRIMARY KEY (`Student_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `student_record`
--

INSERT INTO `student_record` (`Student_ID`, `Roll_no`, `Name`, `F_Name`, `email`, `CNIC`, `City`, `Country`, `Religion`, `Mobile`, `Program`, `Session`, `Gender`) VALUES
(26, 3, 'Adnan Ghouri', 'Javed Ghouri', 'adnanghouri@gmail.com', '36154-85749652-7', 'Bahawalpur', '165', 'Islam', '12345678', '5', 2012, 'male'),
(27, 4, 'Muhammad Zeeshan Iqb', 'Muhammad Iqbal', 'mzeeshanbwp@gmail.com', '31205-6987495-8', 'Bahawalpur', 'pakistan', 'Islam', '1234567', '3', 2012, 'male'),
(28, 7, 'Muhammad Fareed', 'Muhammad Akhtar', 'abss@gmail.com', '31202-3121838-9', 'Bahawalpur', '165', 'Islam', '0300-1234567', '6', 2013, 'male');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_record`
--

CREATE TABLE IF NOT EXISTS `teacher_record` (
  `Teacher_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Name` char(50) NOT NULL,
  `F_Name` char(50) NOT NULL,
  `CNIC` varchar(50) NOT NULL,
  `Mobile` int(20) NOT NULL,
  `Designation` varchar(50) NOT NULL,
  `Salary` int(50) NOT NULL,
  `join_date` date NOT NULL,
  `Leave_date` date NOT NULL,
  `city` char(20) NOT NULL,
  `country` int(10) NOT NULL,
  `Qualification` char(20) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`Teacher_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `teacher_record`
--

INSERT INTO `teacher_record` (`Teacher_ID`, `Name`, `F_Name`, `CNIC`, `Mobile`, `Designation`, `Salary`, `join_date`, `Leave_date`, `city`, `country`, `Qualification`, `gender`, `email`) VALUES
(4, 'Ali Ahmad', 'Muhammad Ahmad', '31206-6352879-9', 323, 'Permanent Teacher', 15, '2015-12-31', '2015-12-31', 'Bahawalpur', 165, 'M.Phill', 'male', 'ali_ahmad@gmail.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
