<?php
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Fees Details</h1>
				</div>
			</div>
		</div>
	</header>
	
	

	<!-- container -->
	<div class="container">
		<div class="row">
			<!-- Article content -->
			<section class="col-sm-12 maincontent">
				<h3>Here is our Fee Details</h3>
				<p>
					Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
					Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
					when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
					It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
					It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
					and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
				</p>

			</section>
		</div>
	</div>
	<!-- /container -->
	
	<div class="container">
		<div class='row'>
			<ul class="nav nav-tabs" role="tablist" id="myTab">
			  <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">M. Phill </a></li>
			  <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Masters</a></li>
			  <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Bachelor</a></li>
			  <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">Short Cources</a></li>
			</ul>

			<div class="tab-content">
			  <div role="tabpanel" class="tab-pane active" id="home">
				<div class="row">
					<div class='col-sm-12'>
					</br>
						<h4>COMPUTER SCIENCE, PHYSICS, MATHEMATICS.</h4>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Duration</p>
						<p>Registration Fee (Only Once):</p>
						<p>Fee (Per Semester):</p>
						<p>Affliation With:</p>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Semester System (4 Semester)</p>
						<p>Rs. 20,000/-</p>
						<p>Rs. 40,000/-</p>
						<p>University Of Sarghodha</p>
					</div>
				</div>
				<hr>
				<!-- -------------------------------------------------------- -->
				<div class="row">
					<div class='col-sm-12'>
						<h4>ISLAMIC STUDIES, URDU HISTORY, EDUCATION.</h4>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Duration</p>
						<p>Registration Fee (Only Once):</p>
						<p>Fee (Per Semester):</p>
						<p>Affliation With:</p>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Semester System (4 Semester)</p>
						<p>Rs. 20,000/-</p>
						<p>Rs. 40,000/-</p>
						<p>University Of Sarghodha</p>
					</div>
				</div>
				<hr>
<!-- --------------------M.Phill Complete--------------------- -->
<!-- --------------------Masters start------------------------- -->
			  
			  
			  </div>
			  <div role="tabpanel" class="tab-pane" id="profile">
				<div class="row">
				</br>
					<div class='col-sm-12'>
						<h4>M.sc(IT).</h4>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Duration</p>
						<p>Registration Fee (Only Once):</p>
						<p>Fee (Per Semester):</p>
						<p>Affliation With:</p>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Semester System (4 Semester)</p>
						<p>Rs. 10,000/-</p>
						<p>Rs. 35,000/-</p>
						<p>University Of Sarghodha</p>
					</div>
				</div>
				<hr>
				<!-- -------------------------------------------------------- -->
				<div class="row">
					<div class='col-sm-12'>
						<h4>MCS.</h4>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Duration</p>
						<p>Registration Fee (Only Once):</p>
						<p>Fee (Per Semester):</p>
						<p>Affliation With:</p>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Semester System (4 Semester)</p>
						<p>Rs. 10,000/-</p>
						<p>Rs. 35,000/-</p>
						<p>Islamia University Of Bahawalpur</p>
					</div>
				</div>
				<hr>
				<!-- -------------------------------------------------------- -->
				
				<div class="row">
					<div class='col-sm-12'>
						<h4>M.A(English)</h4>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Duration</p>
						<p>Registration Fee (Only Once):</p>
						<p>Fee (Per Month):</p>
						<p>Fee (Per Six Month):</p>
						<p>Affliation With:</p>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Annual System (2 Year)</p>
						<p>Rs. 8,000/-</p>
						<p>Rs. 4,000/-</p>
						<p>Rs. 22,500/-</p>
						<p>Islamia University Of Bahawalpur</p>
					</div>
				
				</div>
				<hr>
				<div class="row">
					<div class='col-sm-12'>
						<h4>MSC (Mathematics).</h4>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Duration</p>
						<p>Registration Fee (Only Once):</p>
						<p>Fee (Per Month):</p>
						<p>Fee (Per Year):</p>
						<p>Affliation With:</p>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Semester System (4 Semester)</p>
						<p>Rs. 8,000/-</p>
						<p>Rs. 4,000/-</p>
						<p>Rs. 48,000/-</p>
						<p>Islamia University Of Bahawalpur</p>
					</div>
				</div>
				<hr>
				<!-- -------------------------------------------------------- -->
				<div class="row">
					<div class='col-sm-12'>
						<h4>MSC (Phusics).</h4>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Duration</p>
						<p>Registration Fee (Only Once):</p>
						<p>Fee (Per Semester):</p>
						<p>Affliation With:</p>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Semester System (4 Semester)</p>
						<p>Rs. 10,000/-</p>
						<p>Rs. 35,000/-</p>
						<p>Islamia University Of Bahawalpur</p>
					</div>
				</div>
				<hr>
				
<!-- --------------------MS Complete--------------------- -->
<!-- --------------------Bachelor start------------------------- -->
			  </div>
			  <div role="tabpanel" class="tab-pane" id="messages">
			  <div class="row">
					<div class='col-sm-12'>
					</br>
						<h4>BS(CS).</h4>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Duration</p>
						<p>Registration Fee (Only Once):</p>
						<p>Fee (Per Semester):</p>
						<p>Affliation With:</p>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Semester System (4 Semester)</p>
						<p>Rs. 20,000/-</p>
						<p>Rs. 40,000/-</p>
						<p>University Of Sarghodha</p>
					</div>
				</div>
				<hr>
				<!-- -------------------------------------------------------- -->
				<div class="row">
					<div class='col-sm-12'>
						<h4>BS(IT).</h4>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Duration</p>
						<p>Registration Fee (Only Once):</p>
						<p>Fee (Per Semester):</p>
						<p>Affliation With:</p>
					</div>
					<div class='col-sm-6 col-xs-6'>
						<p>Semester System (4 Semester)</p>
						<p>Rs. 20,000/-</p>
						<p>Rs. 40,000/-</p>
						<p>University Of Sarghodha</p>
					</div>
				</div>
				<hr>
				<!-- -------------------------------------------------------- -->
				
			  </div>
			  <div role="tabpanel" class="tab-pane" id="settings">
				</br>
				<h4>No Cource Offer Yet</h4>
			  </div>
			</div>
		</div>
	</div>
	
	
<?php
	require('footer.php');
?>