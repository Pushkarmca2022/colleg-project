<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'teacher'){
	ob_clean();
	ob_start();
	
	if(isset($_POST['submit'])){
		$Subject = mysqli_real_escape_string($con,$_POST['subject']);
		$Message = mysqli_real_escape_string($con,$_POST['announcement']);

		$query = "INSERT INTO announcement (Subject,Message) VALUES ('$Subject','$Message')";
		if(mysqli_query($con,$query)){
			$_SESSION['count'] = 0; 
			$_SESSION['msgs']= "Added Successfully.";
		}
	}
	require('header.php');
?>

	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Announcement</h1>
				</div>
			</div>
		</div>
	</header>

	<div class='container margin'>
		<div class='row'>
			<div style="font-weight:bold; color:red;">
				<?php 
				if(isset($_SESSION['msgs']) && isset($_SESSION['count'])){ 
					if($_SESSION['count'] < 1){
						$_SESSION['count'] +=1;
						echo $_SESSION['msgs'];
						unset($_SESSION['msgs']);
					} 
				} ?>
			</div>
			<div class='col-sm-8 col-sm-offset-2'>
				<form method="post" accept="" class="inline">
					<div class="form-group">
						<input type="text" name="subject" id="subject" class="form-control" require placeholder='Enter Subject'>
					</div>
					<div class="form-group">
						<textarea cols="10" rows="6" class='form-control' require placeholder='Type here ...' name="announcement"></textarea>
					</div>
					<input type='submit' value="Add Result" class="btn btn-success" name="submit">
				</form>
			</div>
		</div>		
	</div>
<?php
	require('footer.php');
	}else{
		echo "Access Denied";
	}
?>