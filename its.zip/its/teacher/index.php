<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT * FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
		$email = $fetch['Email'];
	if($role === 'teacher'){
	ob_clean();
	ob_start();
	require('header.php');
?>

	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					
					<?php
					if(!empty($email)){
						$query = "SELECT * FROM teacher_record WHERE email='$email'";
						$run_query = mysqli_query($con,$query);
						$fetch = mysqli_fetch_assoc($run_query);
						$Name = $fetch['Name'];
						if($Name != ' '){ ?>
							<h1><?php echo $Name;?></h1> <?php
						}else{ ?>
							<h1>Welcome Teacher</h1> <?php
						}
					}else{ ?>
						<h1>Welcome Teacher</h1> <?php
					}?>
				</div>
			</div>
		</div>
	</header>
	
	<section style='margin: 50px auto; background-color: #eee;'>
	
		<div class='container'>
			<div class='row'>
				<div class='col-sm-6'>
					<div class="newsBox">
                        <div class="thumbnail">
							<a href='result.php'>
                            <figure><time datetime="2014-01-01">Result</time>
							<img src='../assets/images/result.jpg' class='img-responsive'></figure>
                            <div class="caption maxheight2"><div class="box_inner">
                               Upload Result
                            </div></div></a>
                        </div>
                    </div>
				</div>
				<div class='col-sm-6'>
					<div class="newsBox">
                        <div class="thumbnail">
							<a href='announcement.php'>
                            <figure><time datetime="2014-01-01">Students</time>
							<img src='../assets/images/important_announcement.jpg' class='img-responsive'></figure>
                            <div class="caption maxheight2"><div class="box_inner">
                               Add / Edit or Remove Students
                            </div></div></a>
                        </div>
                    </div>
				</div>
			</div>		
		</div>
	
	</section>
	
<?php
	require('footer.php');
	}else{
		echo "Access Denied";
	}
?>