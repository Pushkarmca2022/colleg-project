<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'teacher'){
	ob_clean();
	ob_start();
	require('header.php');

?>

	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Upload Assignment</h1>
				</div>
			</div>
		</div>
	</header>

	<section class='margin'>
		<div class="row">
			<div class="container">
				<div class="col-sm-10 col-sm-offset-1">
					<form class="inline">
						<div class="">

						</div>  ,
					</form>	
				</div>
			</div>
		</div>

	</section>


<?php
	require('footer.php');
	}else{
		echo "Access Denied.";
	}

?>