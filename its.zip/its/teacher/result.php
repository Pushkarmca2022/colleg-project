<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'teacher'){
	ob_clean();
	ob_start();
	require('header.php');

	$error = array();
	$success = array();

	if(isset($_POST['add_Result'])){
		
		$program = mysqli_real_escape_string($con,$_POST['program']);
		$Marks = mysqli_real_escape_string($con,$_POST['Marks']);
		$Cgpa = mysqli_real_escape_string($con,$_POST['Cgpa']);
		$Roll_No = mysqli_real_escape_string($con,$_POST['Roll_No']);
		$Gpa = mysqli_real_escape_string($con,$_POST['Gpa']);
		$sql = "INSERT INTO result(Program_Id,Roll_No, Marks,Gpa, Cgpa)VALUES('$program','$Roll_No','$Marks','$Gpa','$Cgpa')";
		if(mysqli_query($con,$sql)){
			
			$_SESSION['count'] = 0; 
			$_SESSION['msgs']= "Result added Successfully.";
		}
	}
?>
	
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Result</h1>
				</div>
			</div>
		</div>
	</header>

	<div class='container margin'>
		<div class='row' style="min-height: 350px;">
			<div style="font-weight:bold; color:red;">
				<?php 
				if(isset($_SESSION['msgs']) && isset($_SESSION['count'])){ 
					if($_SESSION['count'] < 1){
						$_SESSION['count'] +=1;
						echo $_SESSION['msgs'];
						unset($_SESSION['msgs']);
					} 
				} ?>
			</div>
			<form method="post" action="result.php" class="inline">
				<div class="col-sm-6">
					<div class="form-group">
						<label for="rollno">Select Program</label>
						<select name='program' class='form-control' required id='country'>
							<option disabled selected value=''>Select Program</option>
							<?php
								$query = "SELECT * FROM program";
								$run_query = mysqli_query($con,$query);
								while($fetch = mysqli_fetch_assoc($run_query)){
							?>
							<option value='<?php echo $fetch['Program_Id'] ?>'><?php echo $fetch['Programe_Name']. ' - ' .$fetch['term']; ?></option>
							<?php } ?>
						</select>
					</div>
					<div class='from-group'>
						<label for='Marks'>Marks</label>
						<input type='text' name='Marks' class='form-control' required />
					</div>
					<div class='from-group'>
						<label for='Cgpa'>Cgpa</label>
						<input type='text' name='Cgpa' class='form-control' required />
					</div>
				</div>
				<div class="col-sm-6">
					<div class='form-group'>
						<label for='Roll_No'>Select Roll Number</label>
						<select name='Roll_No' class='form-control' required id='country'>
							<option disabled selected value=''>Select Roll No</option>
							<?php
								$query = "SELECT Roll_no, Student_ID FROM student_record";
								$run_query = mysqli_query($con,$query);
								while($fetch = mysqli_fetch_assoc($run_query)){
							?>
							<option value='<?php echo $fetch['Student_ID'] ?>'><?php echo $fetch['Roll_no']; ?></option>
							<?php } ?>
						</select>
					</div>
					<div class='from-group'>
						<label for='Gpa'>Gpa</label>
						<input type='text' name='Gpa' class='form-control' required />
					</div>
				</div>
				<div class='row'>
					<div class='col-sm-6' style='margin-top: 20px; '>
						<div class='from-group'>
							<input type='submit' name='add_Result' value="Add Result" class='form-control btn'>
						</div>
					</div>
				</div>
			</form>
		</div>		
	</div>

<?php
	require('footer.php');
	}else{
		header('location:../index.php');
	}
?>