<?php
	require('config.php');
	session_start();
	if(isset($_POST['sendmessage'])){

		$con_name = mysqli_real_escape_string($con, $_POST['con_name']);
		$con_email = mysqli_real_escape_string($con, $_POST['con_email']);
		$con_phone = mysqli_real_escape_string($con, $_POST['con_phone']);
		$con_subject = mysqli_real_escape_string($con, $_POST['con_subject']);
		$con_message = mysqli_real_escape_string($con, $_POST['con_message']);
		
		/* If e-mail is not valid show error message */
		if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/", $con_email)){
			$_SESSION['count'] = 0; 
			$_SESSION['msgs']= "Email is not correct.";
		}else{
			$qry="INSERT INTO contact(Contact_Name,Contact_Email,Contact_Phone,Contact_Subject,Contact_Message)
			VALUES('$con_name','$con_email','$con_phone','$con_subject','$con_message')";
			if(mysqli_query($con,$qry)){
				$_SESSION['count'] = 0; 
				$_SESSION['msgs']= "Email send Successfully.";
			}
		}
	}		
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Contact us</h1>
				</div>
			</div>
		</div>
	</header>

	<!-- container -->
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h3 class="section-title">Your Message</h3>
				<div style="font-weight:bold; color:red;">
					<?php 
					if(isset($_SESSION['msgs']) && isset($_SESSION['count'])){ 
						if($_SESSION['count'] < 1){
							$_SESSION['count'] +=1;
							echo $_SESSION['msgs'];
							unset($_SESSION['msgs']);
						} 
					} ?>
				</div>
				<p>
				Lorem Ipsum is inting and typesetting in simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the is dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
				</p>
				
				<form method="POST" action="contact.php" name="ContactUs" class="form-light mt-20" role="form">
					<div class="form-group">
						<label>Name</label>
						<input name="con_name" type="text" class="form-control" placeholder="Your name" required />
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Email</label>
								<input name="con_email" type="email" class="form-control" placeholder="Email address" required />
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Phone</label>
								<input name="con_phone" type="number" class="form-control" placeholder="Phone number" required />
							</div>
						</div>
					</div>
					<div class="form-group">
						<label>Subject</label>
						<input name="con_subject" type="text" class="form-control" placeholder="Subject" required />
					</div>
					<div class="form-group">
						<label>Message</label>
						<textarea name="con_message" class="form-control" id="message" placeholder="Write you message here..." style="height:100px;" required></textarea>
					</div>
					<button name="sendmessage" type="submit" class="btn btn-two">Send message</button><p><br/></p>
				</form>
			</div>
			<div class="col-md-6">
				<div class="row">
					<div class="col-md-6">
						<h3 class="section-title">Office Address</h3>
						<div class="contact-info">
							<h5>Address</h5>
							<p>I.T.S Collages Ghaziabad</p>
							
							<h5>Email</h5>
							<p>Pushakrmca2019@gmail.com</p>
							
							<h5>Phone</h5>
							<p>+91 770 3801 967</p>
						</div>
					</div>
					<div class="col-md-6">
						<h3 class="section-title">Timings</h3>
						<div class="contact-info">
							<h5>Monday - Friday</h5>
							<p>09:00 AM - 3:30 PM</p>
							
							<h5>Saturday</h5>
							<p>Closed</p>
							
							<h5>Sunday</h5>
							<p>Closed</p>
						</div>
					</div>
				</div>
				<h3 class="section-title">Get connected</h3>
				<p>
				Lorem ipsumn qersl ioinm sersoe non urna dolor sit amet, consectetur piesn qersl ioinm sersoe non urna dolor aecena.
				</p>						
			</div>
		</div>
	</div>
	<!-- /container -->

	

	
	<?php
	require('Footer.php');
	?>