<?php
	require('config.php');
	require('header.php');
?>

	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Faculty Members</h1>
				</div>
			</div>
		</div>
	</header>
	
	<!-- /container -->
    <section class="team-content" style='margin-top: 50px;'>
        <div class="container">
            <div class="row">
			<?php
				$i=1;
				$query = "SELECT *FROM facility ORDER BY Facility_Id ASC";
				$result = 	mysqli_query($con, $query);
				  while( $row = mysqli_fetch_assoc($result) ){
					$Facility_Id = $row['Facility_Id'];
					$Facility_image = $row['Facility_image'];
					$Facility_Name = $row['Facility_Name']; ?>
					<div class="col-md-3 col-sm-3 col-xs-6" style="min-height : 300px;">
						<!-- Team Member -->
						<div class="team-member" >
							<!-- Image Hover Block -->
							<div class="member-img">
								<!-- Image  -->
								<img src="<?php $path = "uploaded/facility/";
									if(file_exists($path.$Facility_image)){
										if(strpos($Facility_image,".gif")||strpos($Facility_image,".jpeg")||strpos($Facility_image,".jpg")||strpos($Facility_image,".JPG")||strpos($Facility_image,".x-png")||strpos($Facility_image,".png")){
											echo $path.$Facility_image;
										}
									}
									else{
										echo $path."noimage.jpg";
									}
									?>" alt="" style="height : 200px;" >
							</div>
							<!-- Member Details -->
							<h4><?php echo $Facility_Name;?></h4>
						</div>
					</div> <?php
				  }						
			?>
            </div>
        </div>
    </section>


<?php	require('footer.php'); ?>