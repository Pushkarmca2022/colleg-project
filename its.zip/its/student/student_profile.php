<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'student'){
	ob_clean();
	ob_start();
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>My Profile</h1>
				</div>
			</div>
		</div>
	</header>
<?php
	$student_id = $_SESSION['id'];
	$query = "SELECT Email FROM login WHERE Login_ID='$student_id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$email = $fetch['Email'];
	$query = "SELECT * FROM student_record WHERE email='$email'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$Student_ID = $fetch['Student_ID'];
		$roll_no = $fetch['Roll_no'];
		$fname = $fetch['F_Name'];
		$sname = $fetch['Name'];
		$email = $fetch['email'];
		$cnic = $fetch['CNIC'];
		$city = $fetch['City'];
		$country = $fetch['Country'];
		$mobile = $fetch['Mobile'];
		$Religion = $fetch['Religion'];
		$program = $fetch['Program'];
		$session = $fetch['Session'];
?>
	<section class='margin'>
			<div class="container">
				<div class="row">
					<div class="col-md-offset-2 col-xs-offset-1" style="font-weight:bold; color:red;">
						<?php 
						if(isset($_SESSION['msgs']) && isset($_SESSION['count'])){ 
							if($_SESSION['count'] < 1){
								$_SESSION['count'] +=1;
								echo $_SESSION['msgs'];
								unset($_SESSION['msgs']);
							}else{
								session_destroy();
							}
						} ?>
					</div>
					<form method="post" action="stdprofile.php">
						<input type="hidden"  name="hidId" id="hidId" value="<?php echo $Student_ID;?>"/>
						<div class="col-sm-6">
							<div class="form-group">
								<label for="rollno">Roll Number</label>
								<input type='text' name='rollno' id="rollno" readonly="readonly" class="form-control" value="<?php echo $roll_no;?>">
							</div>
							<div class="form-group">
								<label for="sname">Name</label>
								<input type='text' name='sname' id="sname" class="form-control" value="<?php echo $sname;?>">
							</div>
							<div class="form-group">
								<label for="fname">Father Name</label>
								<input type='text' name='fname' id="fname" class="form-control" value="<?php echo $fname;?>">
							</div>
							<div class="form-group">
								<label for="email">Email Id</label>
								<input type='text' name='email' id="email" class="form-control" readonly="readonly" value="<?php echo $email;?>">
							</div>
							<div class="form-group">
								<label for="cnic">CNIC</label>
								<input type='text' name='cnic' id="cnic" readonly="readonly" class="form-control" value="<?php echo $cnic;?>">
							</div>
							<div class="form-group">
								<label for="Mobile">Religion</label>
								<input type='text' name='Religion' id="Mobile" class="form-control" value="<?php echo $Religion;?>">
							</div>
						</div>

						<div class="col-sm-6">
							<div class="form-group">
								<label for="City">City</label>
								<input type='text' name='City' id="City" value="<?php echo $city?>" class="form-control">
							</div>
							<div class="form-group">
								<label for="country">Country</label>
								<input type='text' name='country' id="country" class="form-control" value="<?php echo $country;?>">
							</div>
							
							<div class="form-group">
								<label for="Mobile">Mobile</label>
								<input type='text' name='Mobile' id="Mobile" class="form-control" value="<?php echo $mobile;?>">
							</div>
							<div class="form-group">
								<label for="Program">Program</label>
								<input type='text' name='Program' id="Program" readonly="readonly" class="form-control" value="<?php echo $program;?>">
							</div>
							<div class="form-group">
								<label for="session">Session</label>
								<input type='text' name='session' id="session" readonly="readonly" class="form-control" value="<?php echo $session;?>">
							</div>
						</div>
						<div class='col-sm-2 col-sm-offset-5'>
							<input type="submit" name="update_profile" value="Update Profile" class="btn btn-success">
						</div>
					</form>
				</div>
			</div>
	</section>
<?php
	require('footer.php');
	}else{
		echo "Access Denied";
	}
?>