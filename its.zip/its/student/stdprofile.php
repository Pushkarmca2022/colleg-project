<?php
	session_start();
	require('../config.php');
	if(isset($_POST['update_profile'])){
		$hidId = mysqli_real_escape_string($con, $_POST['hidId']);
		$rollno = mysqli_real_escape_string($con, $_POST['rollno']);
		$sname = mysqli_real_escape_string($con, $_POST['sname']);
		$fname = mysqli_real_escape_string($con, $_POST['fname']);
		$email = mysqli_real_escape_string($con, $_POST['email']);
		$cnic = mysqli_real_escape_string($con, $_POST['cnic']);
		$City = mysqli_real_escape_string($con, $_POST['City']);
		$country = mysqli_real_escape_string($con, $_POST['country']);
		$Mobile = mysqli_real_escape_string($con, $_POST['Mobile']);
		$Program = mysqli_real_escape_string($con, $_POST['Program']);
		$session = mysqli_real_escape_string($con, $_POST['session']);
		$Religion = mysqli_real_escape_string($con, $_POST['Religion']);
		
		$query1 = "UPDATE student_record SET Roll_no='$rollno',Name='$sname',F_Name='$fname',email='$email',CNIC='$cnic',City='$City',Country='$country',Religion='$Religion',Mobile='$Mobile',Program='$Program',Session='$session' WHERE(Student_ID='$hidId')";
		if($query_run=mysqli_query($con, $query1)){
			$_SESSION['count'] = 0; 
			$_SESSION['msgs']= "Profile Updated Successfully.";
			header('location:student_profile.php');
		}
	}else{
		header('location:student_profile.php');
	}
?>