<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'student'){
	ob_clean();
	ob_start();
	require('header.php');
?>

	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Check Announcement</h1>
				</div>
			</div>
		</div>
	</header>

	<section class='margin minheight'>
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<table class="table table-bordered table-striped">
						<thead>
							<tr>
								<td>Sr.No</td>
								<td>Subject</td>
								<td width="500">Announcemnt</td>
								<td>Date</td>
							</tr>
						</thead>
					<?php
						$query = "SELECT * FROM announcement";
						$run_query = mysqli_query($con,$query);
						$i = 1;
						while($fetch = mysqli_fetch_assoc($run_query)){
					?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $fetch['subject']; ?></td>
							<td><?php echo $fetch['announcement']; ?></td>
							<td><?php echo $fetch['date']; ?></td>
						</tr>
					
					<?php $i++; } ?>
					</table>
				</div> 
			</div>
		</div>
	</section>
<?php
	require('footer.php');
	}else{
		echo "Access Denied";
	}
?>