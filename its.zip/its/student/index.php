<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT * FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
		$email = $fetch['Email'];
	if($role === 'student'){
	ob_clean();
	ob_start();
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<?php
					$query = "SELECT * FROM student_record WHERE email='$email'";
					$run_query = mysqli_query($con,$query);
					$fetch = mysqli_fetch_assoc($run_query);
						$Name = $fetch['Name'];
					?>
						<h1><?php echo $Name;?></h1>
				</div>
			</div>
		</div>
	</header>
	
	<section style='margin: 50px auto; background-color: #eee;'>
	
		<div class='container'>
			<div class='row' style="min-height: 320px;">
				<div class='col-sm-12'>
					Welcome To student Portal
				</div>
				
			</div>		
		</div>
	
	</section>
	
<?php
	require('footer.php');
	}else{
		header('location:../index.php');
	}
?>