<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->  
<head>
    <?php include('links.php');?>
</head> 
<body class="home-page">
    <div class="wrapper">
        <!-- ******HEADER START****** --> 
        <?php include('header.php');?>
		<!-- ******menu nav****** --> 
		<?php include('nav.php');?>
		<div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">TAXILA – DAY EXCURSION</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="index.php">Home</a><i class="fa fa-angle-right"></i></li>
							<li class="current"><a href="package.php">Buddhist Package</a><i class="fa fa-angle-right"></i></li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
				<div class="page-content">
                    <div class="row page-row">
						<div class="col-md-3 col-sm-3 left-services package-left">
							<a href="bst.php"><p >Buddhist Study Tour</p></a>
							<a href="gbt.php"><p class="active2">Gandhara Buddha TOur, - [Cultural and Heritage Tours]</p></a>
							<a href="texila.php"><p>Taxila Day Trip</p></a>
							<a href=""><p>Swat Trip</p></a>
						</div>
						<article class="welcome col-md-6 col-sm-6 class="image-tag">
							<div class="row ">
								<div class="col-md-4 col-sm-4 ">
									<img src="assets/images/gbt/r0015381a.jpg"  class="image-tag"/r0015381a>
								</div>
								<div class="col-md-4 col-sm-4 " >
									<img src="assets/images/gbt/img_0424.jpg"  class="image-tag"/>
								</div>
								<div class="col-md-4 col-sm-4">
									<img src="assets/images/gbt/img_0426.jpg"  class="image-tag" />
								</div>
							</div>
                            <P>The Gandhara tour is designed to explore the hidden treasures of ancient history and the marvels of nature of the northern valleys of Pakistan. The Gandhara Civilization (500 BC to 10th Century AD), an era devoted mainly to Buddhism, has been the centre of spiritual influence as well as art and architecture. It was from here that Buddhism spread towards east as far as Japan and Korea. Despite the vagaries of centuries, Taxila and Swat Valley have preserved these heritages in art and craft. Peshawar and Swat host the finest remains of the civilization. But the more intriguing is the visit of the archaeological sites spread all over Taxila, Swat and other parts of North West Frontier Province of Pakistan and the Gilgit-Baltistan that have been discovered in the twentieth century. Along with the journey into the history, one enjoys the splendors of nature while traveling in the valleys of Swat, Indus, Gilgit and Hunza.</p>
							<P><strong>Day 01</strong>-   Arrival Islamabad Reception and transfer to hotel, PM Sightseeing</p>
							<P><strong>Day 02</strong> -  Islamabad-Peshawar Enroute Visit Taxila Museum and transfer to Peshawar</p>
							<P><strong>Day 03</strong> - Peshawar Sightseeing of Peshawar.</p>
							<P><strong>Day 04</strong> Peshawar-Swat Transfer to Swat. Enroute visit Takht Bhai site.</p>
							<P><strong>Day 05 </strong>Swat Sightseeing of Swat.</p>
							<P><strong>Day 06</strong>Swat-Besham Drive to Besham over Shangla Pass.	</p>
							<P><strong>Day 07</strong>  Besham-Gilgit Continue drive to Gilgit. Enroute visit rock carvings at Shatial,Chilas and Alam Bridge.</p>
							<P><strong>Days 08</strong> - Gilgit Sightseeing of Gilgit and visit rock inscriptions Danyore Village and Konodas and Buddha image at Kargah.</p>
							<P><strong>Day 09 </strong>- Gilgit-Hunza Drive to Hunza and visit Altit and Baltit Forts.</p>
							<P><strong>Day 10 </strong>- Hunza Reserved for optional exploration or rest.</p>
							<P><strong>Day 11</strong> - Hunza-Gulmit Full day excursion of Khunjerab Pass and back to Gulmit.</p>
							<P><strong>Day 12</strong> - Gulmit-Gilgit Return back to Gilgit.</p>
						</article><!--//page-content-->
						
                        <aside class="page-sidebar  col-md-2 col-sm-3">                    
                            <?php include('right-menu.php');?>
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
			</div><!--//page--> 
        </div><!--//content-->
    </div><!--//wrapper-->	
	
	<?php include('footer.php');?>
    
    <?php include('right_profile.php');?>
 
    <?php include('bottom_script.php');?>  
	</body>
</html>
		<?php include('footer.php');?>
	</body>
</html>