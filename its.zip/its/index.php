<?php
	require('config.php');
	require('header.php');
	
?>

	<header id="head">
	<h1>I.T.S Collages</h1>
		<div class="container">
			<div class="banner-content">
				<div id="da-slider" class="da-slider">
					<div class="da-slide">
						<h2>College Management System</h2>
						<p>We can built the future of <span  style="color:lightgreen;">Ghaziabad</span></p>
						<div class="da-img"></div>
					</div>
					<div class="da-slide">
						<h2>Online Education</h2>
						<p>Web based College management system..</p>
						<div class="da-img"></div>
					</div>
					<div class="da-slide">
						<h2>Super Success</h2>
						<p>Web based College management system..</p>
						<div class="da-img"></div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- /Header -->

	   <section class="container">
		<div class="heading">
			<!-- Heading -->
			<h2 align='center'>Welcome TO College</h2>
		</div>
		<div class="row">
			<div class="col-md-3 col-sm-3">
				<img src="assets/images/4.jpg" alt="Professor Dr. Qaiser Mushtaq" width='100%' class="img-responsive">
				<p class='text-center'><b> Director sunil Pandey</b></p>
				<p class='text-justify'>I welcome you on behalf of College Management System. College Management System is taking off with high goals and spirits. Our aim is not only to prepare young generation for degree but also to groom them ethically, socially, culturally and professionally so that they can step into their practical life with confidence.</p>
			</div>
			<div class="col-md-9 col-sm-9">
				<p class='text-justify'>College Management System is a newly established institution aiming to prepare students to step into their professional/practical life with confidence.</p>
				<p class='text-justify'>College Management System is run by Global Education Foundation. Its base College is situated at Bahawalpur.</p>

				<p class='text-justify'>College Management System is taking of with Programs in Computer studies and Information Technology.  In today’s modern world, computer science and IT professionals has collaborated with scientist, business professionals, health care providers, game designers and countless other professions, to provide them with information and solve major problems.</p>

				<p class='text-justify'>College Management System aims to educate students in necessary computer theory and skills so they are adequately prepared to work effectively across disciplines.</p>

				<p class='text-left'><b>We also intend to offer short courses like</b></p>

				&rarr; Game Programming<br>
				&rarr; Web Engineering With PHP<br>
				&rarr; C #<br>
				&rarr; C++ (Beginer & Advance)<br>
				&rarr; Business English<br>
				<br>
				<p class='text-justify'>College Management System intend to offers students a dynamic, supportive and creative environment in which they will be encouraged by a committed staff, to pursue personal excellence in academic pursuits, resulting in enhanced prospects for career development.</p>

				<p class='text-justify'>College Management System offers students the opportunity to learn in small groups, enhancing the student progression through personalised attention. Progression will be regularly assessed, measured and monitored to deliver a high quality education.</p>
				
				<p class='text-justify'>We have well-equipped multi-media classrooms along with computer laboratory and a well-resourced library. We have High-speed broadband internet in our computer laboratory. Our library is open after teaching hours for students who wish to avail of our self-study facilities</p>
			</div>
		</div>
		
	</section>
	
	<section class="fetures" style='margin-top: 50px'>
        <div class="container">
			<div class='row'>
				<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
					<div class="newsBox">
                        <div class="thumbnail">
							<a href=''>
                            <figure><time datetime="2014-01-01">Check Assignment Online</time>
							<img src='assets/images/assignment.jpg' class='img-responsive'></figure>
                            <div class="caption maxheight2"><div class="box_inner">
                               Check assignments uploaded by your teacher
                            </div></div></a>
                        </div>
                    </div>
				</div>
				<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
					<div class="newsBox">
                        <div class="thumbnail">
							<a href=''>
								<figure><time datetime="2014-01-01">Check Your Result</time><img src='assets/images/result.jpg' class='img-responsive'></figure>
								<div class="caption maxheight2"><div class="box_inner">
								   Check all semester's result
								</div></div>
							</a>
                        </div>
                    </div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="newsBox">
                        <div class="thumbnail">
							<a href=''>
								<figure><time datetime="2014-01-01">Downloads</time><img src='assets/images/downloads.jpg' class='img-responsive'></figure>
								<div class="caption maxheight2"><div class="box_inner">
								   Download E-Books, Date Sheets
								</div></div>
							</a>
                        </div>
                    </div>
                </div>
			</div>
		</div>
	</section>
      
      
    
      
      <section class="news-box">
        <div class="container">
            <h2><span>Latest News and Events</span></h2>
            <div class="row">
			<?php
				$query = "SELECT *FROM event ORDER BY Event_Id DESC limit 4";
				$result = 	mysqli_query($con, $query);
				while( $row = mysqli_fetch_assoc($result) ){
					$Event_Date = $row['Event_Date'];
					$Event_image = $row['Event_image'];
					$Event_Description = $row['Event_Description']; ?>
					<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
						<div class="newsBox">
							<div class="thumbnail">
								<figure>
									<time datetime="2014-01-01"><?php echo $Event_Date;?></time>
									<img src="<?php $path = "uploaded/";
										if(file_exists($path.$Event_image)){
											if(strpos($Event_image,".gif")||strpos($Event_image,".jpeg")||strpos($Event_image,".jpg")||strpos($Event_image,".JPG")||strpos($Event_image,".x-png")||strpos($Event_image,".png")){
												echo $path.$Event_image;
											}
										}
										else{
											echo $path."noimage.jpg";
										}
										?>" alt="" style="height : 200px;" >
								</figure>
								<div class="caption maxheight2"><div class="box_inner">
								   <?php echo $Event_Description;?>
								</div></div>
							</div>
						</div>
					</div> <?php
				}
			?>
            </div>
        </div>
    </section>
 <?php
	require('footer.php');
 ?>