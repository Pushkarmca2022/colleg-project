<?php
	session_start();
	require('../config.php');
		if(isset($_POST['add_event'])){
			$name = @$_FILES['file']['name'];
			$temp_name = @$_FILES['file']['tmp_name'];
			$Summery = isset($_POST["Summery"])?$_POST["Summery"]:"";
			$title = isset($_POST["event_date"])?$_POST["event_date"]:"";
		
			if (($_FILES["file"]["size"] < 2000000)) {
				if ($_FILES["file"]["error"] > 0) {
					$_SESSION['count'] = 0; 
					$_SESSION['msgs']= "Return Code: " . $_FILES["file"]["error"] . "<br>";
				}else {
					$pathname = "../uploaded/";
					if (!file_exists($pathname)){
						mkdir($pathname);
					}
					if (file_exists($pathname ."/" . $_FILES["file"]["name"])) {	
						$_SESSION['count'] = 0; 
						$_SESSION['msgs']= $_FILES["file"]["name"] . " already exists. ";
					} else {
						if(move_uploaded_file($_FILES["file"]["tmp_name"],$pathname ."/" . $_FILES["file"]["name"]));
							$query = "INSERT INTO event(Event_Date,Event_image,Event_Description) values('$title','$name','$Summery') ";
							$query_run = mysqli_query($con, $query);
							$_SESSION['count'] = 0; 
							$_SESSION['msgs']= "Event Added successfully.";
					}
				}
			} else {
				$_SESSION['count'] = 0; 
				$_SESSION['msgs']= "Size is more than.";
			}
		}
	//-----DELETE FROM LINKS WHEN ACTION PERFORM
	if(isset($_GET['action'])){
		if($_GET['action']=='delete'){
			$Event_id = mysqli_real_escape_string($con, $_GET['Event_id']);
			$Eventimage = $_GET['Eventimage'];
			$query = "DELETE FROM event WHERE Event_Id='$Event_id'";
			if(mysqli_query($con,$query)){
				if(file_exists("../uploaded/".$Eventimage)) {
					unlink("../uploaded/".$Eventimage);
					$_SESSION['count'] = 0; 
					$_SESSION['msgs']= "File deleted successfully.";
				}
			}
		}
	}
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Add New And Events</h1>
				</div>
			</div>
		</div>
	</header>	
		<div class='container'>
			<div class='row'>
				<div class='col-sm-12'>
					<h2 class='text-center'>Latest Events</h2>
					<div style="font-weight:bold; color:red;">
						<?php 
						if(isset($_SESSION['msgs']) && isset($_SESSION['count'])){ 
							if($_SESSION['count'] < 1){
								$_SESSION['count'] +=1;
								echo $_SESSION['msgs'];
								unset($_SESSION['msgs']);
							} 
						} ?>
					</div>
					<form method='post' name="event" action="event.php" enctype="multipart/form-data">
						<div class='row'>
							<div class='col-md-5 col-sm-5'>
								<div class="form-group ">
									<label for='f_name'>Date Picking</label>
									<div class="controls input-append date form_date" data-date="" data-date-format="dd MM yyyy" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
										<input name="event_date" size="16" type="text" value="" readonly style="width : 100%; height : 40px;">
										<span class="add-on"><i class="icon-remove"></i></span>
										<span class="add-on"><i class="icon-th"></i></span>
									</div>
									<input type="hidden" id="dtp_input2" value="" /><br/>
								</div>
							</div>
							<div class='col-md-4 col-sm-4'>
								<div class='form-group'>
									<label for='f_name'>Event Image</label>
									<input type="file" name="file" id="file" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class='col-md-5 col-sm-5'>
								<div class='form-group'>
									<label for='student_name'>Event Description</label>
									<textarea rows="2" cols="20" name="Summery" id="Summery" class="form-control"  placeholder="Summery" required="required"></textarea>
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-md-2 col-sm-1' style='margin-top: 20px; '>
								<div class='from-group'>
									<input type='submit' name='add_event' value="Add Event" class='form-control btn'>
								</div>
							</div>
						</div>	
						<div class='table-responsive'>
							<table class='table table-bordered table-striped table-hover'>
								<thead>
									<tr class="datagrid2">
										<th>Id</th>
										<th>Event Date</th>
										<th>Image</th>
										<th>Summery</th>
										<th>Delete</th>
									</tr>
								</thead>
								<tbody class="datagrid2">
								<?php
								$i=1;
								$query = "SELECT *FROM event ORDER BY Event_Id DESC";
								$result = 	mysqli_query($con, $query);
								  while( $row = mysqli_fetch_assoc($result) ){
									$Event_Id = $row['Event_Id'];
									$Event_Date = $row['Event_Date'];
									$Event_image = $row['Event_image'];
									$Event_Description = $row['Event_Description']; ?>
									
									<td><?php echo $i; ?></td>
									<td><?php echo $Event_Date ?></td>
									<td>
										<?php
										if(strpos($Event_image,".gif")||strpos($Event_image,".jpeg")||strpos($Event_image,".jpg")||strpos($Event_image,".pjpeg")||strpos($Event_image,".x-png")||strpos($Event_image,".png")) {?>
											<img src="../uploaded/<?php echo $Event_image; ?>" alt="<?php echo $Event_image; ?>" style="color:green; width:20px; height:20px;" />
											<?php 
										}
										?>
									</td>
									<td><?php echo $Event_Description ?></td>
									<td class = "action">
										<a href="event.php?Event_id=<?=$Event_Id?>&Eventimage=<?=$Event_image?>&action=delete" class="delete">Delete</a>
									</td>
								</tr> <?php
								$i++;
								} ?>
								</tbody>
							  &nbsp;
							</table>
						</div>
					</form>
				</div>
			</div>
		</div>	

<?php
	require('footer.php');
?>