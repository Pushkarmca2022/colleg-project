<?php
	session_start();
	require('../config.php');
		if(isset($_POST['add_facility'])){
			$name = @$_FILES['file']['name'];
			$temp_name = @$_FILES['file']['tmp_name'];
			$Facility_Name = isset($_POST["Facility_Name"])?$_POST["Facility_Name"]:"";
			
		
			if (($_FILES["file"]["size"] < 2000000)) {
				if ($_FILES["file"]["error"] > 0) {
					$_SESSION['count'] = 0; 
					$_SESSION['msgs']= "Return Code: " . $_FILES["file"]["error"] . "<br>";
				}else {
					$pathname = "../uploaded/facility/";
					if (!file_exists($pathname)){
						mkdir($pathname);
					}
					if (file_exists($pathname ."/" . $_FILES["file"]["name"])) {	
						$_SESSION['count'] = 0; 
						$_SESSION['msgs']= $_FILES["file"]["name"] . " already exists. ";
					} else {
						if(move_uploaded_file($_FILES["file"]["tmp_name"],$pathname ."/" . $_FILES["file"]["name"]));
							$query = "INSERT INTO facility(Facility_image,Facility_Name) values('$name','$Facility_Name') ";
							$query_run = mysqli_query($con, $query);
							$_SESSION['count'] = 0; 
							$_SESSION['msgs']= "Facility Member Added successfully.";
					}
				}
			} else {
				echo "<h3 class='col-sm-12 tex-center text-success'>File size exceeded from 2mb.</h3>";
			}
		}
	//-----DELETE FROM LINKS WHEN ACTION PERFORM
	if(isset($_GET['action'])){
		if($_GET['action']=='delete'){
			$Facility_id = mysqli_real_escape_string($con, $_GET['Facility_id']);
			$Facility_image = $_GET['Facility_image'];
			$query = "DELETE FROM facility WHERE Facility_Id='$Facility_id'";
			if(mysqli_query($con,$query)){
				if(file_exists("../uploaded/facility/".$Facility_image)) {
					unlink("../uploaded/facility/".$Facility_image);
					$_SESSION['count'] = 0; 
					$_SESSION['msgs']= "File deleted successfully.";
				}
			}
		}
	}
	require('header.php');
?>
	
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Add New Faculty Members</h1>
				</div>
			</div>
		</div>
	</header>	
		<div class='container'>
			<div class='row'>
				<div class='col-sm-12'>
					<h2 class='text-center'>Faculty Members Detail</h2>
					<div style="font-weight:bold; color:red;">
						<?php 
						if(isset($_SESSION['msgs']) && isset($_SESSION['count'])){ 
							if($_SESSION['count'] < 1){
								$_SESSION['count'] +=1;
								echo $_SESSION['msgs'];
								unset($_SESSION['msgs']);
							} 
						} ?>
					</div>
					<form method='post' name="event" action="facility.php" enctype="multipart/form-data">
						<div class='row'>
							<div class='col-md-4 col-sm-4'>
								<div class='form-group'>
									<label for='f_name'>Facility Member Image</label>
									<input type="file" name="file" id="file" required />
								</div>
							</div>
							<div class='col-md-5 col-sm-5'>
								<div class="form-group ">
									<label for='f_name'>Facility Member Name</label>
									<input type='text' name='Facility_Name' class='form-control' required />
								</div>
							</div>
						</div>
						
						<div class='row'>
							<div class='col-md-2 col-sm-1' style='margin-top: 20px; '>
								<div class='from-group'>
									<input type='submit' name='add_facility' value="Add Member" class='form-control btn'>
								</div>
							</div>
						</div>	
						<div class='table-responsive'>
							<table class='table table-bordered table-striped table-hover'>
								<thead>
									<tr class="datagrid2">
										<th>Id</th>
										<th>Facility Image</th>
										<th>Title</th>
										<th>Delete</th>
									</tr>
								</thead>
								<tbody class="datagrid2">
								<?php
								$i=1;
								$query = "SELECT *FROM facility ORDER BY Facility_Id DESC";
								$result = 	mysqli_query($con, $query);
								  while( $row = mysqli_fetch_assoc($result) ){
									$Facility_Id = $row['Facility_Id'];
									$Facility_image = $row['Facility_image'];
									$Facility_Name = $row['Facility_Name']; ?>
									
									<td><?php echo $i; ?></td>
									<td>
										<?php
										if(strpos($Facility_image,".gif")||strpos($Facility_image,".jpeg")||strpos($Facility_image,".jpg")||strpos($Facility_image,".pjpeg")||strpos($Facility_image,".x-png")||strpos($Facility_image,".png")) {?>
											<img src="../uploaded/facility/<?php echo $Facility_image; ?>" alt="<?php echo $Facility_image; ?>" style="color:green; width:20px; height:20px;" />
											<?php 
										}
										?>
									</td>
									<td><?php echo $Facility_Name ?></td>
									<td class = "action">
										<a href="facility.php?Facility_id=<?=$Facility_Id?>&Facility_image=<?=$Facility_image?>&action=delete" class="delete">Delete</a>
									</td>
								</tr> <?php
								$i++;
								} ?>
								</tbody>
							  &nbsp;
							</table>
						</div>
					</form>
				</div>
			</div>
		</div>	

<?php
	require('footer.php');
?>