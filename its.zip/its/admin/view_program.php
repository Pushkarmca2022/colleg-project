<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'admin'){
	ob_clean();
	ob_start();
	require('header.php');

	if(isset($_GET['delete'])){
		$id = mysqli_real_escape_string($con,$_GET['delete']);
		$query = "DELETE FROM program WHERE Program_Id='$id'";
		$run_query = mysqli_query($con,$query);
		if($run_query){
			header('location: view_program.php');
		}else{
			echo "Error";
		}
	}
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Welcome Admin</h1>
				</div>
			</div>
		</div>
	</header>	
	<div class='container'>
		<div class='row'>
			<div class='col-sm-12'>
				<h2 class='text-center'>View Program</h2>
				<div class='table-responsive'>
					<table class='table table-bordered table-striped table-hover'>
						<tr>
							<th>Program Name</th>
							<th>Affiliated With</th>
							<th>Session</th>
							<th>Term</th>
							<th>Edit</th>
							<th>Delete</th>
						</tr>
						<?php
							$query = "SELECT * FROM program";
							$run = mysqli_query($con,$query);
							while($fetch = mysqli_fetch_assoc($run)){
						?>
						<tr>
							<td><?php echo $fetch['Programe_Name']; ?></td>
							<td><?php if($fetch['Affiliated_Id']=="UOS") echo "University Of Sarghoda"; if($fetch['Affiliated_Id']=="IUB") echo "Islamia University of Bahawalpur";  ?></td>
							<td><?php echo $fetch['session']; ?></td>
							<td><?php echo $fetch['term']; ?></td>
							<td><a href='edit_program.php?edit=<?php echo $fetch['Program_Id']; ?>'><i class="fa fa-pencil-square-o fa-2x"></i> </a></td>
							<td><a href='view_program.php?delete=<?php echo $fetch['Program_Id']; ?>'><i class="fa fa-trash-o fa-2x"></i> </a></td>
						</tr>
						<?php } ?>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php
	require('footer.php');
	}else{
		echo "Access Denied.";
	}
?>