<?php
	session_start();
	ob_start();
	require('../config.php');
	
?>