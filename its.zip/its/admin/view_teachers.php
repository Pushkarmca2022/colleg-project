<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'admin'){
	ob_clean();
	ob_start();
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Welcome Admin</h1>
				</div>
			</div>
		</div>
	</header>	
		<div class='container'>
			<div class='row'>
				<div class='col-sm-12'>
					<h2 class='text-center'>All Teachers</h2>
					<?php
						if(isset($_GET['delete'])){
							$id = mysqli_real_escape_string($con,$_GET['delete']);
							$q = "SELECT email FROM teacher_record WHERE Teacher_ID='$id'";
							$run = mysqli_query($con,$q);
							$fetch = mysqli_fetch_assoc($run);
								$email = $fetch['email'];
							$query = "DELETE FROM teacher_record WHERE Teacher_ID='$id'";
							$query1 = "DELETE FROM login WHERE email='$email'";
							if($run_query = mysqli_query($con,$query) && $run_query1 = mysqli_query($con,$query1)){
								header('LOCATION: view_teachers.php');
							}else{
								echo "<h3 class='text-center text-danger'>Fail to Delete student</h3>";
							}
						}
						
						if (isset($_POST['export_teachers'])) {
							$filename  = "exports/" . strtotime("now") . '.csv';
							$query     = "SELECT * FROM teacher_record";
							$run_query = mysqli_query($con, $query);
							$row       = mysqli_num_rows($run_query);
							if ($row > 0) {
								$fopen     = fopen($filename, "w");
								$fetch     = mysqli_fetch_assoc($run_query);
								$separator = "";
								$comma     = "";
							   
								foreach ($fetch as $name => $value) {
									$separator .= $comma . '"' . str_replace('"', '\"', $name) . '"';
									$comma = ",";
								}
								$separator .= "\n";
								$fputs = fputs($fopen, $separator);
								mysqli_data_seek($run_query,0);
								while ($fetch = mysqli_fetch_assoc($run_query)) {
									$separator = "";
									$comma     = "";
								   
									foreach ($fetch as $name => $value) {
										$separator .= $comma . '"' . str_replace('"', '\"', $value) . '"';
										$comma = ",";
									}
									$separator .= "\n";
									$fputs = fputs($fopen, $separator);
								}
								echo "<h3 class='text-center text-success'><a href='$filename'>Download Now</a></h3>";
							   
							} else {
								echo "No Record Found.";
							}
						   
						}
						
					?>
					<div class='table-responsive'>
						<table class='table table-bordered table-striped table-hover'>
							<tr>
								<th>Name</th>
								<th>Father Name</th>
								<th>CNIC</th>
								<th>Mobile</th>
								<th>Designation</th>
								<th>Salary</th>
								<th>City</th>
								<th>Join / Leave Date </th>
								<th>Qualifications</th>
								<th>Email</th>
								<th>Edit</th>
								<th>Delete</th>
							</tr>
							<?php
								$query = "SELECT * FROM teacher_record";
								$run_query = mysqli_query($con,$query);
								while($fetch = mysqli_fetch_assoc($run_query)){
							?>
							<tr>
								<td><?php echo $fetch['Name'];?></td>
								<td><?php echo $fetch['F_Name'];?></td>
								<td><?php echo $fetch['CNIC'];?></td>
								<td><?php echo $fetch['Mobile'];?></td>
								<td><?php echo $fetch['Designation'];?></td>
								<td><?php echo $fetch['Salary'];?></td>
								<td><?php echo $fetch['city'];?></td>
								<td><?php echo $fetch['join_date'] . ' <b>/</b> ' . $fetch['Leave_date'];?></td>
								<td><?php echo $fetch['Qualification'];?></td>
								<td><?php echo $fetch['email'];?></td>
								<td><a href='edit_teacher.php?edit=<?php echo $fetch['Teacher_ID']; ?>'><i class="fa fa-pencil-square-o fa-2x"></i> </a></td>
								<td><a href='view_teachers.php?delete=<?php echo $fetch['Teacher_ID']; ?>'><i class="fa fa-trash-o fa-2x"></i> </a></td>
							</tr>
							<?php } ?>
						</table>	
					</div>
					<div class='text-right'>
						<form method='post'>
							<button type='submit' class='btn' name='export_teachers'>Export</button>
						</form>
					</div>
				</div>
			</div>
		</div>
<?php
	require('footer.php');
	}else{
		echo "Access Denied.";
	}
?>