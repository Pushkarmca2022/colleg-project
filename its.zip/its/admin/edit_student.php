<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'admin'){
	ob_clean();
	ob_start();
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Welcome Admin</h1>
				</div>
			</div>
		</div>
	</header>	
		<div class='container'>
			<div class='row'>
				<div class='col-sm-12'>
					<h2 class='text-center'>Edit Student Record</h2>
					<?php
					
						if(isset($_POST['edit_student'])){
							if(isset($_GET['edit'])){
							
								$id = strip_tags(mysqli_real_escape_string($con,$_GET['edit']));
								$student_name = strip_tags(mysqli_real_escape_string($con,$_POST['student_name']));
								$f_name = strip_tags(mysqli_real_escape_string($con,$_POST['f_name']));
								$roll_no = strip_tags(mysqli_real_escape_string($con,$_POST['roll_no']));
								$email = strip_tags(mysqli_real_escape_string($con,$_POST['email']));
								$program = strip_tags(mysqli_real_escape_string($con,$_POST['program']));
								$cnic = strip_tags(mysqli_real_escape_string($con,$_POST['cnic']));
								$session = strip_tags(mysqli_real_escape_string($con,$_POST['session']));
								$city = strip_tags(mysqli_real_escape_string($con,$_POST['city']));
								$country = strip_tags(mysqli_real_escape_string($con,$_POST['country']));
								$mobile = strip_tags(mysqli_real_escape_string($con,$_POST['mobile']));
								$gender = strip_tags(mysqli_real_escape_string($con,$_POST['gender']));
								$religion = strip_tags(mysqli_real_escape_string($con,$_POST['religion']));
								
												
								$query = "UPDATE student_record SET Name='$student_name', F_Name='$f_name', email='$email', Program='$program', CNIC='$cnic', Session='$session', Country='$country', Mobile='$mobile', Gender='$gender' , Religion='$religion' , Roll_no='$roll_no' , City= '$city' WHERE Student_ID = '$id'";
								
								if($run_query = mysqli_query($con,$query)){
									echo "<h3 class='text-center text-success'>Successfully Edited Student Information</h3>";
								}else{
									echo "<h3 class='text-center text-danger'>Error in Updating information</h3>";
								}
								
							}
						}
						
						if(isset($_GET['edit'])){
							$id = strip_tags(mysqli_real_escape_string($con,$_GET['edit']));
							$query = "SELECT * FROM student_record WHERE Student_ID='$id'";
							$run_query = mysqli_query($con,$query);
							$row = mysqli_num_rows($run_query);
							if($row>0){
							
								$fetch = mysqli_fetch_assoc($run_query);
								$roll_no = $fetch['Roll_no'];
								$name = $fetch['Name'];
								$F_Name = $fetch['F_Name'];
								$email = $fetch['email'];
								$CNIC = $fetch['CNIC'];
								$City = $fetch['City'];
								$Country = $fetch['Country'];
								$Religion = $fetch['Religion'];
								$Mobile = $fetch['Mobile'];
								$Program = $fetch['Program'];
								$Session = $fetch['Session'];
					?>
					<form method='post'>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='student_name'>Student Name</label>
									<input type='text' id='student_name' name='student_name' class='form-control' value='<?php if(isset($name)) echo $name;?>' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='f_name'>Father Name</label>
									<input type='text' id='f_name' name='f_name' class='form-control' value='<?php if(isset($F_Name)) echo $F_Name;?>' required />
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='student_name'>Roll Number</label>
									<input type='text' id='roll_no' name='roll_no' class='form-control' value='<?php if(isset($roll_no)) echo $roll_no;?>' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='class'>Program</label>
									<select name='program' class='form-control' required id='country'>
										<option disabled selected value=''>Select Program</option>
										<?php
											$query = "SELECT * FROM program";
											$run_query = mysqli_query($con,$query);
											while($fetch = mysqli_fetch_assoc($run_query)){
										?>
										<option value='<?php echo $fetch['Program_Id'] ?>'><?php echo $fetch['Programe_Name']. ' - ' .$fetch['term']; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='session'>Session</label>
									<input type='text' id='session' name='session' class='form-control' value='<?php if(isset($Session)) echo $Session;?>' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='roll_no'>
									<label for='cnic'>CNIC</label>
									<input type='text' id='cnic' name='cnic' class='form-control'  value='<?php if(isset($CNIC)) echo $CNIC;?>' required />
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='city'>City</label>
									<input type='text' id='city' name='city' class='form-control' value='<?php if(isset($City)) echo $City;?>' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='country'>Country</label>
									<select name='country' class='form-control' required id='country'>
										<option disabled selected value=''>Select Country</option>
										<?php
											$query = "SELECT * FROM countries";
											$run_query = mysqli_query($con,$query);
											while($fetch = mysqli_fetch_assoc($run_query)){
										?>
										<option value='<?php echo $fetch['id'] ?>'><?php echo $fetch['country_name']; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='mobile'>Mobile</label>
									<input type='text' id='mobile' name='mobile' class='form-control' value='<?php if(isset($Mobile)) echo $Mobile;?>' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<div class='col-sm-6'>
									<label for='male' class='text-cetner'>Male</label>
									<input type='radio' name='gender' class='form-control' required id='male' value='male'>
									</div>
									<div class='col-sm-6'>
									<label for='female' class='text-cetner'>Female</label>
									<input type='radio' name='gender' class='form-control' required id='female' value='female'>
									</div>
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='from-group'>
									<label for='religion'>Religion</label>
									<input type='text' id='religion' name='religion' class='form-control' value='<?php if(isset($Religion)) echo $Religion;?>' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='from-group'>
									<label for='email'>Email</label>
									<input type='email' id='email' name='email' class='form-control' value='<?php if(isset($email)) echo $email;?>' required />
								</div>
							</div>
						</div>
						<div class='row' style='margin-top: 20px; '>
							<div class='col-sm-6'>
								<div class='from-group'>
									<input type='submit' name='edit_student' class='form-control btn' value='Edit Now'>
								</div>
							</div>
						</div>	
					</form>
					<?php
					
					}else{
								echo "<h3 class='text-center text-danger'>No Record Found</h3>";
							}
						}
					?>
					
				</div>
			</div>
		</div>	
	
<?php
	require('footer.php');
	}else{
		echo "Access Denied.";
	}
?>