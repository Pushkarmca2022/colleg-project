<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'admin'){
	ob_clean();
	ob_start();
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Welcome Admin</h1>
				</div>
			</div>
		</div>
	</header>	
		<div class='container'>
			<div class='row'>
				<div class='col-sm-12'>
					<h2 class='text-center'>Add Program</h2>
					<?php
						if(isset($_POST['add_program'])){
							$program = strip_tags(mysqli_real_escape_string($con,$_POST['program']));
							$aff = strip_tags(mysqli_real_escape_string($con,$_POST['aff']));
							$session = strip_tags(mysqli_real_escape_string($con,$_POST['session']));
							$term = strip_tags(mysqli_real_escape_string($con,$_POST['term']));
							
							$query = "SELECT * FROM program WHERE Programe_Name	='$program' AND Affiliated_Id='$aff' AND session='$session' AND term='$term'";
							$run_query = mysqli_query($con,$query);
							$row = mysqli_num_rows($run_query);
							if($row > 0){
								echo "<h3 class='text-center text-danger'>Record Already Exist</h3>";
							}else{
								
								$query1 = "INSERT INTO program (Programe_Name,Affiliated_Id,session,term) VALUES('$program','$aff','$session','$term')";
								if($run_query1 = mysqli_query($con,$query1)){
									echo "<h3 class='text-center text-success'>Program Added Successfully</h3>";
								}else{
									echo "<h3 class='text-center text-danger'>Fail to Add Program</h3>";
								}
							}			
						}
					?>
					<form method='post'>
						<div class='row'>
							<div class='col-sm-3'>
								<div class='form-group'>
									<label for='program'>Program Name</label>
									<input type='text' id='program' name='program' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-3'>
								<div class='form-group'>
									<label for='aff'>Affiliated With</label>
									<select id='aff' name='aff' required class='form-control'>
										<option selected disabled value=''>Choose One</option>
										<option value='UOS'>University Of Sarghoda</option>
										<option value='IUB'>Islamia University Of Bahawalpur</option>
									</select>
								</div>
							</div>
							<div class='col-sm-3'>
								<div class='form-group'>
									<label for='session'>Session</label>
									<input type='text' id='session' name='session' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-3'>
								<div class='form-group'>
									<label for='term'>Term</label>
									<input type='text' id='term' name='term' class='form-control' required />
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-offset-3 col-sm-6'>
								<div class='form-group'>
									<input type='submit' value="Add Program" name='add_program' class='btn form-control' />
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
<?php
	require('footer.php');
	}else{
		echo "Access Denied.";
	}
?>