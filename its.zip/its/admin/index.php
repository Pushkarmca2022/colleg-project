<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'admin'){
	ob_clean();
	ob_start();
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Welcome Admin</h1>
				</div>
			</div>
		</div>
	</header>

	<section class="fetures" style='margin-top: 50px'>
        <div class="container">
			<div class='row'>
				<div class='col-sm-4'>
					<div class="newsBox">
                        <div class="thumbnail">
							<a href='view_students.php'>
                            <figure><time datetime="2014-01-01">Students</time>
							<img src='../assets/images/user_student.png' class='img-responsive'></figure>
                            <div class="caption maxheight2"><div class="box_inner">
                               Add / Edit or Remove Students
                            </div></div></a>
                        </div>
                    </div>
				</div>
				<div class='col-sm-4'>
					<div class="newsBox">
                        <div class="thumbnail">
							<a href='view_teachers.php'>
								<figure><time datetime="2014-01-01">Teachers</time><img src='../assets/images/Teacher-icon.png' class='img-responsive'></figure>
								<div class="caption maxheight2"><div class="box_inner">
								   Add / Edit or Remove Teachers
								</div></div>
							</a>
                        </div>
                    </div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                    <div class="newsBox">
                        <div class="thumbnail">
							<a href='view_Program.php'>
								<figure><time datetime="2014-01-01">Programs</time><img src='../assets/images/transcript1.png' class='img-responsive'></figure>
								<div class="caption maxheight2"><div class="box_inner">
								   Add / Remove Programs
								</div></div>
							</a>
                        </div>
                    </div>
                </div>
			</div>
		</div>
	</section>
	
<?php
	require('footer.php');
	}else{
		echo "Access Denied.";
	}
?>