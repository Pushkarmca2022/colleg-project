<?php
	session_start();
	require('../config.php');
	
	require('header.php');
?>
	
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Contact Us</h1>
				</div>
			</div>
		</div>
	</header>	
		<div class='container'>
			<div class='row'>
				<div class='col-sm-12'>
					<h2 class='text-center'>Contact Us View</h2>
					<div style="font-weight:bold; color:red;">
						<?php 
						if(isset($_SESSION['msgs']) && isset($_SESSION['count'])){ 
							if($_SESSION['count'] < 1){
								$_SESSION['count'] +=1;
								echo $_SESSION['msgs'];
								unset($_SESSION['msgs']);
							} 
						} ?>
					</div>
					<form method='post' name="event" action="facility.php" enctype="multipart/form-data">
						
						<div class='table-responsive'>
							<table class='table table-bordered table-striped table-hover'>
								<thead>
									<tr class="datagrid2">
										<th>Sr</th>
										<th>Name</th>
										<th>Email</th>
										<th>Phone</th>
										<th>Subject</th>
										<th>Message</th>
									</tr>
								</thead>
								<tbody class="datagrid2">
								<?php
								$i=1;
								$query = "SELECT *FROM contact ORDER BY Contact_Id DESC";
								$result = 	mysqli_query($con, $query);
								  while( $row = mysqli_fetch_assoc($result) ){
									$Contact_Name = $row['Contact_Name'];
									$Contact_Email = $row['Contact_Email'];
									$Contact_Phone = $row['Contact_Phone'];
									$Contact_Subject = $row['Contact_Subject'];
									$Contact_Message = $row['Contact_Message'];									?>
									
									<td><?php echo $i; ?></td>
									<td><?php echo $Contact_Name;?></td>
									<td><?php echo $Contact_Email ?></td>
									<td><?php echo $Contact_Phone ?></td>
									<td><?php echo $Contact_Subject ?></td>
									<td><?php echo $Contact_Message ?></td>
								</tr> <?php
								$i++;
								} ?>
								</tbody>
							  &nbsp;
							</table>
						</div>
					</form>
				</div>
			</div>
		</div>	

<?php
	require('footer.php');
?>