<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'admin'){
	ob_clean();
	ob_start();
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Welcome Admin</h1>
				</div>
			</div>
		</div>
	</header>	
		<div class='container'>
			<div class='row'>
				<div class='col-sm-12'>
					<h2 class='text-center'>Add Student</h2>
					<?php
						if(isset($_POST['add_student'])){
							$student_name = strip_tags(mysqli_real_escape_string($con,$_POST['student_name']));
							$f_name = strip_tags(mysqli_real_escape_string($con,$_POST['f_name']));
							$roll_no = strip_tags(mysqli_real_escape_string($con,$_POST['roll_no']));
							$email = strip_tags(mysqli_real_escape_string($con,$_POST['email']));
							$program = strip_tags(mysqli_real_escape_string($con,$_POST['program']));
							$cnic = strip_tags(mysqli_real_escape_string($con,$_POST['cnic']));
							$session = strip_tags(mysqli_real_escape_string($con,$_POST['session']));
							$city = strip_tags(mysqli_real_escape_string($con,$_POST['city']));
							$country = strip_tags(mysqli_real_escape_string($con,$_POST['country']));
							$mobile = strip_tags(mysqli_real_escape_string($con,$_POST['mobile']));
							$gender = strip_tags(mysqli_real_escape_string($con,$_POST['gender']));
							$religion = strip_tags(mysqli_real_escape_string($con,$_POST['religion']));
							
							$query = "SELECT email FROM student_record WHERE email='$email'";
							$run_query = mysqli_query($con,$query);
							$row = mysqli_num_rows($run_query);
							if($row>0){
								echo "<h3 class='text-center text-danger'>This Reord Already Exist in our Database</h3>";
							}else{
							
								$query = "INSERT INTO student_record (roll_no, Name, F_Name, email, CNIC, City, Country, Religion, Mobile, Program, Session, Gender) VALUES ('$roll_no','$student_name','$f_name', '$email', '$cnic','$city','$country','$religion','$mobile','$program','$session','$gender')";
								$password = sha1(md5(time() . $email));
								$query1 = "INSERT INTO login (Email, Password, role) VALUES ('$email','$password','student')";
								add_student($email, $password, $student_name);
								
								if($run_query = mysqli_query($con,$query) && $run_query1 = mysqli_query($con,$query1)){
									echo "<h3 class='col-sm-12 tex-center text-success'>Student Added Successfully</h3>";
								}else{
									echo "<h3 class='col-sm-12 tex-center text-danger'>Fail to add teacher</h3>";
								}
							}
						}
					?>
					<form method='post'>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='student_name'>Student Name</label>
									<input type='text' id='student_name' name='student_name' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='f_name'>Father Name</label>
									<input type='text' id='f_name' name='f_name' class='form-control' required />
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='student_name'>Roll Number</label>
									<input type='text' id='roll_no' name='roll_no' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='class'>Program</label>
									<select name='program' class='form-control' required id='country'>
										<option disabled selected value=''>Select Program</option>
										<?php
											$query = "SELECT * FROM program";
											$run_query = mysqli_query($con,$query);
											while($fetch = mysqli_fetch_assoc($run_query)){
										?>
										<option value='<?php echo $fetch['Program_Id'] ?>'><?php echo $fetch['Programe_Name']. ' - ' .$fetch['term']; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='session'>Session</label>
									<select id='session' name='session' class='form-control' required >
										<option disabled selected value=''>Select Session</option>
										<?php
											$query = "SELECT DISTINCT session FROM program";
											$run_query = mysqli_query($con,$query);
											while($fetch = mysqli_fetch_assoc($run_query)){
										?>
										<option value='<?php echo $fetch['session'] ?>'><?php echo $fetch['session']; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='roll_no'>
									<label for='cnic'>CNIC</label>
									<input type='text' id='cnic' name='cnic' class='form-control' required />
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='city'>City</label>
									<input type='text' id='city' name='city' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='country'>Country</label>
									<select name='country' class='form-control' required id='country'>
										<option disabled selected value=''>Select Country</option>
										<?php
											$query = "SELECT * FROM countries";
											$run_query = mysqli_query($con,$query);
											while($fetch = mysqli_fetch_assoc($run_query)){
										?>
										<option value='<?php echo $fetch['id'] ?>'><?php echo $fetch['country_name']; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='mobile'>Mobile</label>
									<input type='text' id='mobile' name='mobile' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<div class='col-sm-6'>
									<label for='male' class='text-cetner'>Male</label>
									<input type='radio' name='gender' class='form-control' required id='male' value='male'>
									</div>
									<div class='col-sm-6'>
									<label for='female' class='text-cetner'>Female</label>
									<input type='radio' name='gender' class='form-control' required id='female' value='female'>
									</div>
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='from-group'>
									<label for='religion'>Religion</label>
									<input type='text' id='religion' name='religion' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='from-group'>
									<label for='email'>Email</label>
									<input type='email' id='email' name='email' class='form-control' required />
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6' style='margin-top: 20px; '>
								<div class='from-group'>
									<input type='submit' name='add_student' value="Add Student" class='form-control btn'>
								</div>
							</div>
						</div>	
					</form>
				</div>
			</div>
		</div>	

<?php
	require('footer.php');
	}else{
		echo "Access Denied.";
	}
?>