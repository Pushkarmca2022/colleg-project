<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'admin'){
	ob_clean();
	ob_start();
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Welcome Admin</h1>
				</div>
			</div>
		</div>
	</header>	
		<div class='container'>
			<div class='row'>
				<div class='col-sm-12'>
					<h2 class='text-center'>All Students</h2>
					<div class="margin">
					 <div id="filter-panel" class="collapse filter-panel">
			            <div class="panel panel-default">
			                <div class="panel-body">
			                    <form class="form-inline pull-right" role="form" method="post">
			                        <div class="form-group">
			                            <label class="filter-col" style="margin-right:0;" for="pref-search">Select Program</label>
			                            <select name="program_name" class="form-control" required="required" >
			                            	<option value="" disabled="disabled" selected="selected">Choose One</option>
			                            	<option value="bscs">BSCS</option>
			                            	<option value="bsit">BSIT</option>
			                            	<option value="MSc(IT)">MSc IT</option>
			                            </select>
			                        </div><!-- form group [search] -->
			                        <div class="form-group">
			                            <label class="filter-col" style="margin-right:0;" for="pref-search">Select Term</label>
			                            <select name="program_term" class="form-control" required >
			                            	<option value="" disabled="disabled" selected="selected">Choose One</option>
			                            	<option value="1st">1st</option>
			                            	<option value="2nd">2nd</option>
			                            	<option value="3rd">3rd</option>
			                            	<option value="4th">4th</option>
			                            	<option value="5th">5th</option>
			                            	<option value="6th">6th</option>
			                            	<option value="7th">7th</option>
			                            	<option value="">8th</option>
			                            </select>
			                        </div><!-- form group [search] -->
			                         <div class="form-group">
			                            <label class="filter-col" style="margin-right:0;" for="pref-search">Select Session</label>
			                            <select name="program_session" class="form-control" required>
			                            	<option value="" disabled="disabled" selected="selected">Choose One</option>
			                            	<?php
			                            		echo $query = "SELECT distinct session FROM program";
			                            		$run_query = mysqli_query($con,$query);
			                            		while($fetch = mysqli_fetch_assoc($run_query)){
			                            	?>
			                            		<option value="<?php echo $fetch['session']; ?>"><?php echo $fetch['session']; ?></option>	
			                            	<?php } ?>
			                            </select>
			                        </div><!-- form group [search] -->
			                        <div class="form-group">    
			                            <button type="submit" class="btn filter-col" name="filter_program">
			                                <span class="glyphicon glyphicon-record"></span> Filter
			                            </button>  
			                        </div>
			                    </form>
			                </div>
			            </div>
			        </div>    
			        <button type="button" class="btn" data-toggle="collapse" data-target="#filter-panel">
			            <i class="glyphicon glyphicon-cog"></i> Filter Students
			        </button>
			        </div>
					<?php
						if(isset($_GET['delete'])){
							$id = mysqli_real_escape_string($con,$_GET['delete']);
							$q = "SELECT email FROM student_record WHERE Student_ID='$id'";
							$run = mysqli_query($con,$q);
							$fetch = mysqli_fetch_assoc($run);
								$email = $fetch['email'];
								
							$query = "DELETE FROM student_record WHERE Student_ID='$id'";
							$query1 = "DELETE FROM login WHERE email='$email'";
							if($run_query = mysqli_query($con,$query) && $run_query1 = mysqli_query($con,$query1)){
								header('LOCATION: view_students.php');
							}else{
								echo "<h3 class='text-center text-danger'>Fail to Delete student</h3>";
							}
						}
						
						if (isset($_POST['export_students'])) {
							$filename  = "exports/" . strtotime("now") . '.csv';
							$query     = "SELECT * FROM student_record";
							$run_query = mysqli_query($con, $query);
							$row       = mysqli_num_rows($run_query);
							if ($row > 0) {
								$fopen     = fopen($filename, "w");
								$fetch     = mysqli_fetch_assoc($run_query);
								$separator = "";
								$comma     = "";
							   
								foreach ($fetch as $name => $value) {
									$separator .= $comma . '"' . str_replace('"', '\"', $name) . '"';
									$comma = ",";
								}
								$separator .= "\n";
								$fputs = fputs($fopen, $separator);
								mysqli_data_seek($run_query,0);
								while ($fetch = mysqli_fetch_assoc($run_query)) {
									$separator = "";
									$comma     = "";
								   
									foreach ($fetch as $name => $value) {
										$separator .= $comma . '"' . str_replace('"', '\"', $value) . '"';
										$comma = ",";
									}
									$separator .= "\n";
									$fputs = fputs($fopen, $separator);
								}
								echo "<h3 class='text-center text-success'><a href='$filename'>Download Now</a></h3>";
							   
							} else {
								echo "No Record Found.";
							}
						   
						}
					?>
					<div class='table-responsive'>
						<table class='table table-bordered table-striped table-hover'>
							<tr>
								<th>Roll No</th>
								<th>Name</th>
								<th>Father Name</th>
								<th>Email</th>
								<th>City</th>
								<th>Country</th>
								<th>CNIC</th>
								<th>Mobile</th>
								<th>Program</th>
								<th>Session</th>
								<th>Edit</th>
								<th>Delete</th>
							</tr>
							<?php
								if(isset($_POST['filter_program'])){

									if((!empty($_POST['program_name'])) AND (!empty($_POST['program_term'])) AND (!empty($_POST['program_session']))){
									
									$program_name = mysqli_real_escape_string($con,$_POST['program_name']);
									$program_term = mysqli_real_escape_string($con,$_POST['program_term']);
									$program_session = mysqli_real_escape_string($con,$_POST['program_session']);
									$query = "SELECT Program_Id FROM program WHERE Programe_Name='$program_name' AND term='$program_term' AND session='$program_session'";
									$run = mysqli_query($con,$query);
									$fetch = mysqli_fetch_assoc($run);
										$program_id = $fetch['Program_Id'];

									$query = "SELECT * FROM student_record WHERE Program='$program_id'";
									$run_query = mysqli_query($con,$query);
									$row = mysqli_num_rows($run_query);
									if($row > 0){
										while($fetch = mysqli_fetch_assoc($run_query)){
											$country = $fetch['Country'];
										$query1 = "SELECT country_name FROM countries WHERE id='$country'";
										$run_query1 = mysqli_query($con,$query1);
											$country_name = mysqli_fetch_assoc($run_query1);
										
										$program = $fetch['Program'];
										$program_query = "SELECT * FROM program WHERE Program_Id='$program'";
										$run_program = mysqli_query($con,$program_query);
										$fetch_program = mysqli_fetch_assoc($run_program);
											$program_name = $fetch_program['Programe_Name'];
											$program_term = $fetch_program['term'];
									?>
									<tr>
										<td><?php echo $fetch['Roll_no'];?></td>
										<td><?php echo $fetch['Name'];?></td>
										<td><?php echo $fetch['F_Name'];?></td>
										<td><?php echo $fetch['email'];?></td>
										<td><?php echo $fetch['City'];?></td>
										<td><?php echo $country_name['country_name'];?></td>
										<td><?php echo $fetch['CNIC'];?></td>
										<td><?php echo $fetch['Mobile'];?></td>
										<td id='program'><?php echo $program_name. '-'. $program_term ;?></td>
										<td><?php echo $fetch['Session'];?></td>
										<td><a href='edit_student.php?edit=<?php echo $fetch['Student_ID']; ?>'><i class="fa fa-pencil-square-o fa-2x"></i> </a></td>
										<td><a href='view_students.php?delete=<?php echo $fetch['Student_ID']; ?>'><i class="fa fa-trash-o fa-2x"></i> </a></td>
									</tr>
							<?php
								}}else
									echo "No Record Found.";
								}else{
									echo "Please Fill all Fields.";
								}
								}
								else{
								$query = "SELECT * FROM student_record";
								$run_query = mysqli_query($con,$query);
								while($fetch = mysqli_fetch_assoc($run_query)){
									$country = $fetch['Country'];
									$query1 = "SELECT country_name FROM countries WHERE id='$country'";
									$run_query1 = mysqli_query($con,$query1);
										$country_name = mysqli_fetch_assoc($run_query1);
									
									$program = $fetch['Program'];
									$program_query = "SELECT * FROM program WHERE Program_Id='$program'";
									$run_program = mysqli_query($con,$program_query);
									$fetch_program = mysqli_fetch_assoc($run_program);
										$program_name = $fetch_program['Programe_Name'];
										$program_term = $fetch_program['term'];
							?>
							<tr>
								<td><?php echo $fetch['Roll_no'];?></td>
								<td><?php echo $fetch['Name'];?></td>
								<td><?php echo $fetch['F_Name'];?></td>
								<td><?php echo $fetch['email'];?></td>
								<td><?php echo $fetch['City'];?></td>
								<td><?php echo $country_name['country_name'];?></td>
								<td><?php echo $fetch['CNIC'];?></td>
								<td><?php echo $fetch['Mobile'];?></td>
								<td id='program'><?php echo $program_name. '-'. $program_term ;?></td>
								<td><?php echo $fetch['Session'];?></td>
								<td><a href='edit_student.php?edit=<?php echo $fetch['Student_ID']; ?>'><i class="fa fa-pencil-square-o fa-2x"></i> </a></td>
								<td><a href='view_students.php?delete=<?php echo $fetch['Student_ID']; ?>'><i class="fa fa-trash-o fa-2x"></i> </a></td>
							</tr>
							<?php }} ?>
						</table>	
					</div>
					<div class='text-right'>
						<form method='post'>
							<button type='submit' class='btn' name='export_students'>Export</button>
						</form>
					</div>
				</div>
			</div>
		</div>

<?php
	require('footer.php');
	}else{
		echo "Access Denied.";
	}
?>
