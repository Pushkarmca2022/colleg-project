<?php
	session_start();
	require('../config.php');
	
	$id = $_SESSION['id'];
	$query = "SELECT role FROM login WHERE Login_ID='$id'";
	$run_query = mysqli_query($con,$query);
	$fetch = mysqli_fetch_assoc($run_query);
		$role = $fetch['role'];
	if($role === 'admin'){
	ob_clean();
	ob_start();
	require('header.php');
?>
	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Welcome Admin</h1>
				</div>
			</div>
		</div>
	</header>	
		<div class='container'>
			<div class='row'>
				<div class='col-sm-12'>
					<h2 class='text-center'>Add Teachers</h2>
					<?php
						if(isset($_POST['add_teacher'])){
							$t_name = strip_tags(mysqli_real_escape_string($con,$_POST['t_name']));
							$f_name = strip_tags(mysqli_real_escape_string($con,$_POST['f_name']));
							$email = strip_tags(mysqli_real_escape_string($con,$_POST['email']));
							$Designation = strip_tags(mysqli_real_escape_string($con,$_POST['Designation']));
							$cnic = strip_tags(mysqli_real_escape_string($con,$_POST['cnic']));
							$qualifications = strip_tags(mysqli_real_escape_string($con,$_POST['qualifications']));
							$city = strip_tags(mysqli_real_escape_string($con,$_POST['city']));
							$country = strip_tags(mysqli_real_escape_string($con,$_POST['country']));
							$mobile = strip_tags(mysqli_real_escape_string($con,$_POST['mobile']));
							$gender = strip_tags(mysqli_real_escape_string($con,$_POST['gender']));
							$j_date = strip_tags(mysqli_real_escape_string($con,$_POST['j_date']));
							$l_date = strip_tags(mysqli_real_escape_string($con,$_POST['l_date']));
							$gender = strip_tags(mysqli_real_escape_string($con,$_POST['gender']));
							$salary = strip_tags(mysqli_real_escape_string($con,$_POST['salary']));
							
							$query = "SELECT email FROM teacher_record WHERE email='$email' AND CNIC='$cnic'";
							$run_query = mysqli_query($con,$query);
							$row = mysqli_num_rows($run_query);
							if($row>0){
								echo "<h3 class='text-center text-danger'>This Reord Already Exist in our Database</h3>";
							}else{
							
								$query = "INSERT INTO teacher_record (Name, F_Name, CNIC, Mobile, Designation, Salary, join_date, Leave_date, City, Country, Qualification, Gender, email) VALUES ('$t_name','$f_name', '$cnic', '$mobile','$Designation','$salary','$j_date', '$l_date','$city','$country','$qualifications','$gender','$email')";
								$password = sha1(md5(time() . $email));
								$query1 = "INSERT INTO login (Email, Password, role) VALUES ('$email','$password','teacher')";
								add_teacher($email, $password, $t_name);
								
								if($run_query = mysqli_query($con,$query) && $run_query1 = mysqli_query($con,$query1)){
									echo "<h3 class='text-center text-success'>Teacher Added Successfully</h3>";
								}else{
									echo "<h3 class='text-center text-danger'>Fail to Add Teacher</h3>";
								}
							}
						}
					?>
					<form method='post'>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='student_name'>Teacher Name</label>
									<input type='text' id='student_name' name='t_name' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='f_name'>Father Name</label>
									<input type='text' id='f_name' name='f_name' class='form-control' required />
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='cnic'>CNIC</label>
									<input type='text' id='cnic' name='cnic' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='mobile'>Mobile</label>
									<input type='text' id='mobile' name='mobile' class='form-control' required />
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='Designation'>Designation</label>
									<input type='text' id='Designation' name='Designation' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='salary'>Salary</label>
									<input type='text' id='salary' name='salary' class='form-control' required />
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='from-group'>
									<label for='city'>City</label>
									<input type='text' id='city' name='city' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='form-group'>
									<label for='country'>Country</label>
									<select name='country' class='form-control' required id='country'>
										<option disabled selected value=''>Select Country</option>
										<?php
											$query = "SELECT * FROM countries";
											$run_query = mysqli_query($con,$query);
											while($fetch = mysqli_fetch_assoc($run_query)){
										?>
										<option value='<?php echo $fetch['id'] ?>'><?php echo $fetch['country_name']; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='from-group'>
									<label for='j_date'>Join Date</label>
									<input type='date' id='j_date' name='j_date' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='from-group'>
									<label for='l_date'>Leave Date <small>( Not Necessary For Now )</small></label>
									<input type='date' id='l_date' name='l_date' class='form-control'  placeholder='Leave Blank for now'/>
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='col-sm-6'>
								<div class='from-group'>
									<label for='qualifications'>Qualifications</label>
									<input type='text' id='qualifications' name='qualifications' class='form-control' required />
								</div>
							</div>
							<div class='col-sm-6'>
								<div class='from-group'>
									<label for='email'>Email</label>
									<input type='email' id='email' name='email' class='form-control' required />
								</div>
							</div>
						</div>	
						<div class='row'>
							<div class='col-sm-6'>
								<div class='form-group'>
									<div class='col-sm-6'>
									<label for='male' class='text-cetner'>Male</label>
									<input type='radio' name='gender' class='form-control' required id='male' value='male'>
									</div>
									<div class='col-sm-6'>
									<label for='female' class='text-cetner'>Female</label>
									<input type='radio' name='gender' class='form-control' required id='female' value='female'>
									</div>
								</div>
							</div>
							<div class='col-sm-6' style='margin-top: 25px;'>
								<div class='from-group'>
									<input type='submit' value="Add Teacher" class='btn btn-block' name='add_teacher' />
								</div>
							</div>	
						</div>
					</form>
				</div>
			</div>
		</div>	

<?php
	require('footer.php');
	}else{
		echo "Access Denied.";
	}
?>