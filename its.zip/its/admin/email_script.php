<?php

	function add_student($email, $password, $name){
	
		$message='
			<p>Hello, '.$name.' </p>
			<p>Your account on Campus Management System has been created as a student and use these credentials to login <small>You can Change Password</small></p>
			<p>Email: '.$email.'</p>
			<p>Password: '.$password.'</p>
			<p><a href="http://localhost/c/login.php">Click Here to Login Now</a></p>
		';
		$to = $email;
		$subject = 'Congratulation! You have been enrolled in Campus Management system';
		
		$from="CAMPUS MANAGEMENT SYSTEM.";
		$reply="adnanghouri97@gmail.com@gmail.com";
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		// Additional headers
		$headers .= 'From:  Campus Management system <'.$from.'>' . "\r\n";
		
	//	mail($to, $subject, $message,$headers);
	}
	
	function add_teacher($email, $password, $name){
	
		$message='
			<p>Hello, '.$name.' </p>
			<p>Your account on  Campus Management system has been created as a teacher and use these credentials to login <small>You can Change Password</small></p>
			<p>Email: '.$email.'</p>
			<p>Password: '.$password.'</p>
			<p><a href="http://localhost/c/login.php">Click Here to Login Now</a></p>
		';
		$to = $email;
		$subject = 'Congratulation! Your Account As a Teacher On  Campus Management system Has been Created!';
		
		$from=" Campus Management system";
		$reply="adnanghouri97@gmail";
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		// Additional headers
		$headers .= 'From:  Campus Management system <'.$from.'>' . "\r\n";
		
	//	mail($to, $subject, $message,$headers);
	}
